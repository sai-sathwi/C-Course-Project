#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int telangana(void);
void telanganac(void);
int kerala(void);
void keralac(void);
int haryana(void);
void haryanac(void);
int karnataka(void);
void karnatakac(void); 
int sikkim(void);
void sikkimc(void);
int uttarkhand(void);
void uttarkhandc(void);
int meghalaya(void);
void meghalayac(void);
int uttar_pradesh(void);
void uttar_pradeshc(void);
int andhra_pradesh(void);
void andhra_pradeshc(void);
int bihar(void);
void biharc(void);
int tamilnadu(void);
void tamilnaduc(void);
int assam(void);
void assamc(void);
int goa(void);
void goac(void);
int gujarat(void);
void gujaratc(void);
int manipur(void);
void manipurc(void);
int rajasthan(void);
void rajasthanc(void); 
/*
void west_bengal(void);
void west_bengalc(void);
void punjab(void);
void punjabc(void);
void mizoram(void);
void mizoramc(void);
void chhattishgarh(void);
void chhattishgarhc(void);
void odisha(void);
void odishac(void);
void nagaland(void);
void nagalandc(void);
void tripura(void);
void tripurac(void);
void jammu_and_kashmir(void);
void jammu_and_kashmirc(void);
void arunalchal_pradesh(void);
void arunalchal_pradeshc(void);*/
int state(char* state)
{
     int x,a,ch;
	 
     printf("\n1.telangana\n2.kerala\n3.haryana\n4.sikkim\n5.uttarkhand\n6.meghalaya\n7.karnataka\n8.uttar pradesh\n9.andhra pradesh\n10.bihar\n11.thamilnadu\n12.assam\n13.goa\n14.gujarat\n15.rajasthan\n16.manipur\n");
     printf("enter the name of the state where you want to take up a job:");
     scanf("%d",&ch);
	 switch(ch){
     	case 1:
     	a=telangana();
     	break;
		 case 2:
		a=kerala();	
			break;
		 case 3:
		a=haryana();
			break;
		 case 4:
		a=sikkim(); 
			break;	
		 case 5:
		a=uttarkhand();
			break; 	
		 case 6:
		a=meghalaya(); 
			break;	
	 	 case 7:
	 	 a=karnataka();	
	 	 	break;
		 case 8:
		a=uttar_pradesh();
			break;	 	
		 case 9:
		a=andhra_pradesh();
			break;	 	
		 case 10:
		 	a=bihar();	
		 		break;
		 case 11:
		a=tamilnadu();
			break;	 	
		 case 12:
		a=assam();
			break;	 	
		 case 13:
		a=goa();
			break;	 	
		 case 14:
		a=gujarat(); 
			break; 	
		 case 15:
		a=rajasthan();
			break; 	
		 case 16:
		 a=manipur();
		 	break;	
	 }
/*	x=strcmpi(state,"telangana");
	if(x==0)
	a=telangana();
	x=strcmpi(state,"kerala");
	if(x==0)
	a=kerala();
	x=strcmpi(state,"haryana");
    if(x==0)
	a=haryana();
	x=strcmpi(state,"sikkim");
	if(x==0)
	a=sikkim();
	x=strcmpi(state,"uttarkhand");
	if(x==0)
	a=uttarkhand();
	x=strcmpi(state,"meghalaya");
	if(x==0)
	a=meghalaya();
	x=strcmpi(state,"karnataka");
	if(x==0)
	a=karnataka();
	x=strcmpi(state,"uttar pradesh");
	if(x==0)
	a=uttar_pradesh();
	x=strcmpi(state,"andhra pradesh");
	if(x==0)
	a=andhra_pradesh();
	x=strcmpi(state,"bihar");
	if(x==0)
	a=bihar();
	x=strcmpi(state,"tamilnadu");
	if(x==0)
	a=tamilnadu();
	x=strcmpi(state,"assam");
	if(x==0)
	a=assam();
	x=strcmpi(state,"goa");
	if(x==0)
	a=goa();
	x=strcmpi(state,"gujarat");
	if(x==0)
	a=gujarat();	
	x=strcmpi(state,"rajasthan");
	if(x==0)
	a=rajasthan();
	x=strcmpi(state,"manipur");
	if(x==0)
	a=manipur();		
	
	/*
	x=strcmpi(state,"west bengal");
	if(x==0)
	west_bengal();

	x=strcmpi(state,"punjab");
	if(x==0)
	punjab();

	x=strcmpi(state,"himachal pradesh");
	if(x==0)
    himachal_pradesh();

	x=strcmpi(state,"mizoram");
	if(x==0)
	mizoram();
	x=strcmpi(state,"chhattishgarh");
	if(x==0)
	chhattishgarh();
	x=strcmpi(state,"odisha");
	if(x==0)
	odisha();
	x=strcmpi(state,"nagaland");
	if(x==0)
	nagaland();
	x=strcmpi(state,"tripura");
	if(x==0)
	tripura();
	x=strcmpi(state,"jammu and kashmir");
	if(x==0)
	jammu_and_kashmir();

	x=strcmpi(state,"arunachal pradesh");
	if(x==0)
	arunalchal_pradesh();


	x=strcmpi(state,"madhya pradesh");
	if(x==0)
	madhya_pradesh();
	x=strcmpi(state,"maharastra");
	if(x==0)
	maharastra();

	x=strcmpi(state,"tripura");
	if(x==0)
	tripura();
	x=strcmpi(state,"jharkhand");
	if(x==0)
	jharkhand();*/
	return a;}		

int telangana(void)
{
	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000 ||to<=43000000 && from>=400000  ){
	printf(" \nMicrosoft IDC, Hyderabad");
	printf("\n");}
	if(salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000 ||to<=20000000 && from>=300000){
	printf("\nAmazon Development Center, Hyderabad");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000 ||to<=9000000 && from>=1000000){
	printf("\nInfosys Limited, Hyderabad");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000 ||to<=7000000 && from>=2000000){
	printf("\nTata Consultancy Services, Hyderabad");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=100000&&70<=percentage ||to<=4000000 && from>=1000000){
	printf("\nWipro Limited, Hyderabad");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60 ||to<=3000000 && from>=500000){
	printf("\nTech Mahindra Limited, Hyderabad");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000 ||to<=3000000 && from>=300000){
	printf("\nCognizant Technology Solutions, Hyderabad");
	printf("\n");}
	if(80<=percentage&&salary<=2000000||salary<=900000&&65<=percentage ||to<=2000000 && from>=900000){
	printf("\nOracle India Pvt Ltd, Hyderabad");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage ||to<=5000000 && from>=400000){
	printf("\nCapgemini Technology Services India Ltd, Hyderabad");
	printf("\n");}
	if(80<=percentage&&salary<=9000000||salary<=800000&&70<=percentage ||to<=9000000 && from>=800000 ){
	printf("\nCyient Ltd, Hyderabad.");
	printf("\n");}
	if(85<=percentage&&salary<=5000000|| salary<=500000&&percentage>=60 ||to<=5000000 && from>=500000){
	printf("\nHCL Technologies Ltd, Hyderabad");
	printf("\n");}
	if(80<=percentage&&salary<=1000000|| salary<=400000&&80<=percentage ||to<=1000000 && from>=400000){
	printf("\nQualcomm India Pvt Ltd, Hyderabad");
	printf("\n");}
	if(percentage>=85&&salary<=1000000|| salary<=400000&&percentage>60 ||to<=1000000 && from>=400000){
	printf("\nAccenture Solutions Pvt Ltd, Hyderabad");
	printf("\n");}
	if(percentage>=75&&salary<=2000000||salary<=600000&&percentage>=55  ||to<=2000000 && from>=600000){
	printf("\nMindtree Ltd, Hyderabad");
	printf("\n");}
	if(percentage>=90&&salary<=5000000||salary<=500000&&percentage>=80 ||to<=5000000 && from>=500000 ){
	printf("\nOracle Financial Services Software Ltd, Hyderabad");
	printf("\n");}  
	if(percentage>=90&&salary<=5000000||salary<=400000&&percentage>=65 ||to<= 5000000&& from>=400000){
	printf(" \nDelloitte Consulting India Pvt Ltd, Hyderabad");
	printf("\n");}
	if(percentage>=85&&salary<=5000000||salary<=400000&&percentage>=60 ||to<=5000000&& from>=400000){
	printf("\nVirtusa Corporation, Hyderabad");
	printf("\n");}
	if(percentage>=80&&salary<=1000000||salary<=300000&&percentage>=60 ||to<=1000000 && from>=300000){
	printf("\nCGI Information Systems & Management Consultants Pvt Ltd, Hyderabad");
	printf("\n");}
	if(percentage>=85&&salary<=900000||salary<=200000&&percentage>=55 ||to<=900000 && from>=200000){
	printf("\nGenpact India Pvt Ltd, Hyderabad");
	printf("\n");}
	if(percentage>80&&salary<=800000||salary<=200000&&percentage>=50||to<=800000&&from>=200000){
	printf("\n IBM India Pvt Ltd, Hyderabad");
	printf("\n");}
  
	telanganac();
	return percentage;
}
void telanganac(void)
{
	int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
	
	a=strcmpi(company,"Microsoft IDC");
    if(a==0)
    {
   	printf("\nMicrosoft India Development Center :");
   	printf("\nWelcome to where excellence is an attitude\nMicrosoft India Development Center is one of Microsoft�s largest R&D centers outside the Redmond headquarters. Set up in Hyderabad in 1998, we represent Microsoft�s strategy of globally shared development to build products and services.");
	printf("\n Microsoft�s three technology groups � Microsoft�s Artificial Intelligence (AI) & Research Group, Cloud & Enterprise Group, and Experience & Devices Group.");
	printf("\naddress:Hyderabad I\nMicrosoft India (R&D) Pvt. Ltd \nMicrosoft\nCampus, Gachibowli, Hyderabad - 500 032\nTel: +91-40-6694 0000\n");
	printf("\nHyderabad II\nMicrosoft Corporation India Pvt. Ltd.\nMicrosoft Corporation India (P) Ltd.\n Vatika Business Centre 3rd Floor, NSL Icon, Road No: 12, Banjara Hills, Hyderabad - 500034. Telangana, India.\nHyderabad III\nMicrosoft Global Services Centre India Pvt. Ltd.\n3rd Floor, Building # 2, ");
	printf("\nMicrosoft Campus, Gachibowli, Hyderabad - 500 032\nTel: +91-40-6694 0000\n");
	printf("\ncontact number:040 6693 6263");
	printf("\nrating: 5");
	}
	a=strcmpi(company,"Amazon Development Center");
	if(a==0)
	{
		printf("\nAmazon Development Center..");
		printf("\nPlace Types:Campus Building");
		printf("\nAddress:Divyasree Trinity Building, Plot No. 6, Hi-Tech City Layout, Survey Number 64, Madhapur Village, Serilingampally, Ranga Reddy District, Phase 2, Hitec City, Hyderabad, Telangana 500081");
		printf("\nCoordinate:17.4477765568, 78.3726961258");
		printf("\nPhone:8873306434");
		printf("\nEmail:amazon_developmentcenter@gmail.com");
		printf("\nSocial:facebook.com/pages /Amazon-Development-Centre..");
		printf("\nWebsite:www.amazon.com");
		printf("\nRating: 5.00");	
	}
	a=strcmpi(company,"Infosys Limited");
	if(a==0){
		printf("\nMain Dc�s branches:\nBanglore DC / Bangalore Branch\nBhuvaneshwar DC\nChandigarh DC\nChennai DC:Chennai SEZ � Mahindra City, Chennai STP\nGurgaon DC\nHyderabad DC�s:Hyderabad SEZ � Largest DC, Hyderabad STP\nJaipur DC\nMangalore DC�s:Mangalore SEZ, Mangalore STP � Very Small\nInfosys Mysore DC\nPune DC�s:Pune Phase 1, Pune Phase 2 � Largest in Pune, Pune Phase 3\nTrivandrum DC");
		printf("\nAddress:Flat No 203 Anjanadri Towers, Pragathi Enclave Colony, Miyapur, Hyderabad, Telangana 500049");
		printf("\nContact number:040 6642 0000");
		printf("\nRating:4.5");
		printf("\nWebsite:www.infosys.com");
		printf("\nsocial:infosys_limited");
		
		
	}
		a=strcmpi(company,"Tata Consultancy Services");
	if(a==0){
		printf("\nAddress: SEZ Unit, Synergy Park, Premises2-56/1/36, Survey Number 26, CMC Campus, Gachibowli, Seri Lingampalli RR District, Hyderabad- 50019");
		printf("\nPOSTS:\nSystem Engineer4,27,271 per year\nAssociate Consultant11,58,307 per year\nTechnical Lead12,55,196 per year");
		printf("\nAhmedabad TCS\nBangalore TCS\nBhubaneswar TCS\nChennai TCS\nCoimbatore TCS\nDelhi TCS\nGandhinagar TCS\nGoa TCS\ngurgaon TCS\nHyderabad TCS\nJamshedpur TCS\nKochi TCS\nKolkata TCS\nLucknow TCS\nmumbai TCS\nnoida TCS\npune TCS\nThiruvananthapuram TCS\n ");
		printf("\nOffice Type: Innovation Lab");
		printf("\nDescription: TCS Innovation Labs � CMC	Address: 5-9-62, 6th Floor Khan Lateef Khan Estate, Fateh Maidan Road Hyderabad 500 001");
		printf("Phone: 91-40-6667 1000\nFax: 91-40-6667 1111");
		printf("\nrating: 4.5");	
	}
		a=strcmpi(company,"Wipro Limited");
	if(a==0){
		printf("\nCorporate Office\nWipro Limited\nDoddakannelli, Sarjapur Road, Bengaluru - 560035\nTel: +91 80 28440011\nFax:+91 80 2844025\n");
		printf("\nAddress:Survey No.124, & Part of 132/P SEZ\nGopanapally\nHyderabad - 501301\n");
		printf("\nPhone: +91 40 30797979, 30970189\n");
		printf("\nFax: +91 40 30970700\n");
		printf("\nBranches:Maharashtra\n Baroda Gujarat\n Mumbai\n Pune\n Ahmedabad Gujarat\n Chennai\nVijayawada\n Secunderabad\n KakkanadCochin\n Bengaluru\n Mysore\n Hyderabad\nKolkata\n Bhubaneswar\nHaryana\nRajasthan\nUttar Pradesh\nGurgaon\nGreater Noida\nNew Delhi");
		printf("\nRating:4.0");	
	}
		a=strcmpi(company,"Tech Mahindra Limited");
	if(a==0){
		printf("\nTech Mahindra represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates, and Society to Rise.");
		printf("\n We are a USD 6.0 billion company with 163,000+ professionals across 90 countries, helping 1279 global customers including Fortune 500 companies.");
		printf("\nTech Mahindra is a part of the Mahindra Group, founded in 1945, one of the largest and most admired multinational federation of companies with 260,000 employees in over 100 countries.");
		printf("\nHeadquarters: Pune, Maharashtra");
		printf("\nSpecialties: Telecom & IT Consulting, Telecom Security Consulting, BSS /OSS, Network Technology Solutions & Services, Network Design & Engineering, Next Generation Networks, Mobility Solutions, Consulting, Solution Integration, IMS, BSG, blockchain, Artificial Intelligence, and Metaverse");
		printf("\nAddress: Unit-12 Plot No 35 & 36, Hitec City Layout, Madhapur, Hyderabad, Telangana 500081");
		printf("\nCompany size: 10,001+ employees");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nWebsite: https://www.techmahindra.com/en-in/ ");
		printf("\nphone no.:040 3063 6363");
		printf("\nrating: 4.5");
	}
		a=strcmpi(company,"Cognizant Technology Solutions");
	if(a==0){
		printf("\nPlace Types :Business Service");
		printf("\nAddress: Gachibowli, Hyderabad 500032");
		printf("\nCoordinate: 17.4475930143, 78.3562294209");
		printf("\nPhone: 040 4451 4444");
		printf("\nEmail:cogizant technology@gmail.com  ");
		printf("\nServices: reserve");
		printf("\nRating: 4.70");
		printf("\nSocial: facebook.com/pages /Cognizant-Technology-Solu..");
		printf("\nWebsite: www.cognizant.com");
	}
		a=strcmpi(company,"Oracle India Pvt Ltd");
	if(a==0){
		printf("\n");
		printf("\nAddress:Salarpuria Cyber Park, Plot no 67, HITEC City, Hyderabad, Telangana 500081, India");
		printf("\nPhone:+91 40 6724 4000");
		printf("\nWebsite:http://oracle.com/");
		printf("\nRating: 3.8");
		printf("\nIndia Development Centres And Global Operations Metros:DELHI/ NATIONAL CAPITAL REGION\nNOIDA\nCHENNAI\nBENGALURU[8]. ");
		printf("\nHYDERABAD\nOracle India Pvt Ltd.\nHYDERABAD- Campus- Phase-I\nHitech City Layout\nMadhapur\nRanga Reddy District\nHyderabad, Telangana - 500 081\nIndia\nPhone:+91 40 6605 0000\nFax: +91 40 6605 9801");
		printf("\nHYDERABAD\nOracle India Pvt Ltd.\nAnanth Info Park\nGround to 7th Floor, Tower C\nHyderabad, Telangana - 500 081\nIndia\nPhone:+91 40 6658 1000\nFax : 91 40 6658 1099\nHYDERABAD - Cyber Park\nOracle India Private Limited.\nCyber Park - Salarpuria\nPlot: 67, Hitec City,\nMadhapur, Hyderabad - 500 081\nTelangana, India\nPhone: +91 40 6724 40000\nFax: +91 40 6740 5640");
		printf("\nWorld Headquarters: Austin\nOracle Corporation\n2300 Oracle Way\nAustin, TX 78741\nCorporate Phone: +1.737.867.1000");

	}
		a=strcmpi(company,"Capgemini Technology Services India Ltd");
	if(a==0){
		printf("\nADDRESS: Plot No: H-08, Sy No: 30 (P), 34-35 (P), Phoenix SEZ, Hitec City 2, Hyderabad, Telangana 500081");
		printf("\nCorporate Identity Number(CIN): U85110PN1993PLC145950");
		printf("\nHead Office, Capgemini Service, Place de l��toile, 11 rue de Tilsitt, 75017 Paris, France");
		printf("\nwebsite: www.capgemini.com");
		printf("\nrating: 4");
		printf("\nphone: +33 1 47 54 50 00 ");
		printf("\nfax: F. +33 1 47 54 50 25  ");
		printf("\n");
		
	}
		a=strcmpi(company,"Cyient Ltd");
	if(a==0){
		printf("Cyient is a consulting-led, industry-centric, global Technology Solutions company. We enable our customers to apply technology imaginatively across their value chain to solve problems that matter. We are committed to designing tomorrow together with our stakeholders and being a culturally inclusive, socially responsible, and environmentally sustainable organization.");
		printf("\naddress: Nsl Sez Arena, 9Th Floor, Block-6, Survey No-1, Plot No 6, Uppal-Ramanthapur Road, Uppal, Hyderabad, Telangana 500039");
		printf("\ncontact.no: 0891 669 3100");
		printf("\nwebsite: e3.cyient.com");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Hyderabad, TS");
		printf("\nType: Public Company");
		printf("\nFounded: 1991");
		printf("Rating: 4");
		printf("\nSpecialties:Engineering Services, Design Led Manufacturing, Networks and Operations, Geospatial, Semiconductor, Technology Solutions, Digital Transformation, and Industry 4.0");
	}
		a=strcmpi(company,"HCL Technologies Ltd");
	if(a==0){
	printf("\nHCLTech is a global technology company, home to 225,900+ people across 60 countries, delivering industry-leading capabilities centered around digital, engineering and cloud, powered by a broad portfolio of technology services and products. We work with clients across all major verticals, providing industry solutions for Financial Services, Manufacturing, Life Sciences and Healthcare, Technology and Services, Telecom and Media, Retail and CPG and Public Services. Consolidated revenues as of 12 months ending March 2023 totaled $12.6 billion. To learn how we can supercharge progress for you, visit hcltech.com");
		printf("Address: HCL Technologies Limited in the city Hyderabad by the address Plot H-01B, Sy.No.30, 34, 35 & 38, Avinash Hitech City2 Society Gachibowli Village, Serillimgampally Mandal, Hyderabad, Telangana 500081, India");
		printf("\nWebsite: http:www.hcltech.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Noida, Uttar Pradesh");
		printf("\nType: Public Company");
		printf("\nFounded: 1991");
		printf("\nSpecialties: Manufacturing, Aerospace & Defense, Financial Services, Telecom, Retail & CPG, Life Sciences & Healthcare, Media & Entertainment, Travel, Transportation & Logistics, Automotive, Government, Energy & Utilities, Consumer Electronics, and Healthcare");
	}
			a=strcmpi(company,"Qualcomm India Pvt Ltd");
	if(a==0){
		printf("\nEnabling a world where everyone and everything can be intelligently connected.");
		printf("\nWebsite: https://www.qualcomm.com/ ");
		printf("\nIndustries: Telecommunications");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: San Diego, CA");
		printf("\nType: Public Company");
		printf("\nSpecialties: Semiconductors, Wireless, Mobile, Networking, Wi-Fi, Small Cells, Wireless Power, Augmented Reality, Location Services, Internet of Things, Automotive, 5G, PC computing, and Bluetooth");
		printf("\nAddress: Hitech City Road Hyderabad, TS 500081, IN");
		printf("\ncontact.no: 092462 99174");
		printf("rating: 4.6");
	}
			a=strcmpi(company,"Accenture Solutions Pvt Ltd");
	if(a==0){
		printf("\nAccenture is a global professional services company with leading capabilities in digital, cloud and security. Combining unmatched experience and specialized skills across more than 40 industries, we offer Strategy and Consulting, Technology and Operations services and Accenture Song�all powered by the world�s largest network of Advanced Technology and Intelligent Operations centers. Our 710,000 people deliver on the promise of technology and human ingenuity every day, serving clients in more than 120 countries. We embrace the power of change to create value and shared success for our clients, people, shareholders, partners, and communities.");
		printf("\nAccenture HDC4, 8-266/7, ISB Rd, Financial District, Nanakram Guda, Hyderabad, Telangana 500032, India, Corporate_office, state TS");
		printf("\nphone: 040 6713 0000");
		printf("\nWebsite: http://www.accenture.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Dublin 2");
		printf("\nType: Public Company");
		printf("rating: 4");
		printf("\nSpecialties: Management Consulting, Systems Integration and Technology, Business Process Outsourcing, and Application and Infrastructure Outsourcing");
		
		
	}
			a=strcmpi(company,"Mindtree Ltd");
	if(a==0){
		printf("\nMindtree is now LTIMindtree, and we are getting businesses to the future, faster. Together. Curious about how we do it? Follow us on www.linkedin.com/ltimindtree/");
		printf("\nAddress: 8th Floor, Building, Mindspace SEZ, Unit No. 801, 12D, Hitech City Rd, Madhapur, Telangana040 6723 0000");
		printf("\n");
		printf("\nWebsite: http://www.ltimindtree.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Bangalore, Karnataka");
		printf("\nType: Public Company");
		printf("\nFounded: 1999");
		printf("rating: 4");
		printf("\nSpecialties: Infrastructure Management Services, Mobility, Independent Testing, Analytics and Information Management, Banking, Financial Services and Insurance, Retail & Consumer Packaged Goods, Manufacturing, Digital Transformation, Cloud, Agile, and Hi-tech, Product IT Operating Model, and Travel, Tourism & Hospitality");
		
	}
			a=strcmpi(company,"Oracle Financial Services Software Ltd");
	if(a==0){
		printf("\nOracle helps banks simplify processes, innovate on demand, and drive predictive insight. Our solutions help banks bring new products to market faster, build customer-centric digital solutions, and achieve success through collaboration in an increasingly complex financial ecosystem.");
		printf("\nWebsite: https://www.oracle.com/in/industries/financial-services/ ");
		printf("\nIndustries: Financial Services");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: MUMBAI, Maharashtra");
		printf("\nType: Privately Held");
		printf("\nphone: 093461 36367");
		printf("Rating: 4");
		printf("\nAddress: 2Nd Floor, Huda Maitrivanam, Ameerpet, Hyderabad, Telangana 500038.");
	}
			a=strcmpi(company,"Delloitte Consulting India Pvt Ltd");
	if(a==0){
		printf("\nDeloitte drives progress. Our firms around the world help clients become leaders wherever they choose to compete. Deloitte invests in outstanding people of diverse talents and backgrounds and empowers them to achieve more than they could elsewhere. Our work combines advice with action and integrity.");
		printf("\nAddress: Meenakshi Techpark,\nGachibowli, Hyderabad, India\nTelangana\n500032");
		printf("\nPhone : +91 (40) 7125 3600");
		printf("\nFax : +91 (40) 7125 3601");
		printf("\nWebsite: http://www.deloitte.com/");
		printf("\nIndustries: Business Consulting and Services");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Worldwide");
		printf("\nType: Privately Held");
		printf("Rating: 4");
		printf("\nSpecialties: Audit, Consulting, Financial Advisory, Risk Management, and Tax Services");
	}
			a=strcmpi(company,"Virtusa Corporation");
	if(a==0){
		printf("\nVirtusa Corporation provides digital engineering and technology services to Forbes Global 2000 companies worldwide. Our Engineering First approach ensures we can execute all ideas and creatively solve pressing business challenges. With industry expertise and empowered agile teams, we prioritize execution early in the process for impactful results.");
		printf("\nCompany size: 10,001+ employees");
		printf("\nAddress: Sy No.115, Aldea Nanakramguda, Serilingampally Mandal, Distrito de Ranga Reddy, Hyderabad, Telangana 500032");
		printf("\nPhone: 040 4452 8000");
		printf("\nWebsite: http://www.virtusa.com");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nHeadquarters: Southborough, MA");
		printf("\nType: Privately Held");
		printf("\nFounded: 1996");
		printf("Rating: 4");
		printf("\nSpecialties: IT Consulting, Technology and Outsourcing Services, Application Maintenance, Development, Systems Integration, Digital Transformation, Digital Engineering, Cloud Transformation, Digital Engineering, and Emerging Technology.");
	}
				a=strcmpi(company,"CGI Information Systems & Management Consultants Pvt Ltd");
	if(a==0){
		printf("\nFounded in 1976, CGI is among the largest IT and business consulting services firms in the world. We are insights-driven and outcomes-based to help accelerate returns on your investments. Across 21 industries in 400 locations worldwide, we provide comprehensive, scalable and sustainable IT and business consulting services that are informed globally and delivered locally.");
		printf("\n2Nd Floor Block 3 Plot No 129, 132, iib Colony Gachibowli Village Serilingampally, Mandal Ap, Hyderabad, Telangana 500032");
		printf("\nPhone: 080664 22222");
		printf("\n Website: https://cgi.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Montreal, Quebec");
		printf("\nType: Public Company");
		printf("\nSpecialties: Business consulting, Systems integration, Intellectual property, Managed IT, Business process services, Digital transformation, Emerging technology, and information technology");
        printf("Rating: 4");
	}
				a=strcmpi(company,"Genpact India Pvt Ltd");
	if(a==0){
	printf("\nGenpact (NYSE: G) is a global professional services firm delivering the outcomes that transform our clients' businesses and shape their future. We're guided by our real-world experience redesigning and running thousands of processes for hundreds of global companies. Our clients � including many in the Fortune Global 500 � partner with us for our unique ability to combine deep industry and functional expertise, leading talent, and proven methodologies to drive collaborative innovation that turns insights into action and delivers outcomes at scale. We create lasting competitive advantages for our clients and their customers, running digitally enabled operations and applying our Data-Tech-AI services to design, build, and transform their businesses.");
        printf("\nWebsite: http://www.genpact.com");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: New York, NY");
		printf("\nType: Public Company");
		printf("\nTwitter: https://twitter.com/genpact, https://twitter.com/Genpact_Careers\nFacebook: https://www.facebook.com/ProudToBeGenpact/\nInstagram: https://www.instagram.com/genpact_careers/\nYouTube: https://www.youtube.com/@GenpactGlobal");
		printf("\nFounded: 1997");
		printf("\nSpecialties: Banking & Financial Services, Energy, Insurance, Healthcare Payer, Capital Market, Healthcare Provider, Aerospace, Hi-Tech, Automotive, Hospitality, Chemical, Life Science & Pharmaceuticals, Consumer Goods, Retail, Telecom, and Transport & Logistics");
        printf("\nAddress: 14-45, Ida Uppal, Opp Ngri, Habsiguda, Hyderabad, Telangana 500039");
        printf("\n Phone: 040 6611 4411");
        printf("\nrating: 4.5");
	}
				a=strcmpi(company,"IBM India Pvt Ltd");
	if(a==0){
		printf("\nAt IBM, we do more than work. We create. We create as technologists, developers, and engineers. We create with our partners. We create with our competitors. If you're searching for ways to make the world work better through technology and infrastructure, software and consulting, then we want to work with you.");
		printf("\nAddress: Mindspace, Building Number. No 3a, 1st Floor, Madhapur, Hyderabad, Telangana 500081");
		printf("\nPhone: 099897 66630");
		printf("\nWebsite: http://www.ibm.com ");
		printf("\nCompany size: 10,001+ employees ");
		printf("\nHeadquarters: Armonk, New York, NY");
		printf("\nType: Public Company");
		printf("\nSpecialties: Cloud, Mobile, Cognitive, Security, Research, Watson, Analytics, Consulting, Commerce, Experience Design, Internet of Things, Technology support, Industry solutions, Systems services, Resiliency services, Financing, and IT infrastructure");
		printf("\nrating: 4.5");
	}
	printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	
	printf("\n*********************************************************");
	printf("\nDo you want to search about other company:");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;}
	}	
}
int kerala(void)
{
   	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000||to<=9000000 && from>=1000000){
	printf(" \n wipro limited_kerala");
	printf("\n");}
	if(3000000<=salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000||to<=7000000 && from>=2000000){
	printf("\nIbyte solutions_kerala");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000||to<=4000000 && from>=1000000){
	printf("\nEmvigo solutions_kerala ");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000||to<=3000000 && from>=500000){
	printf("\ncodelattice digital solutions_kerala");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=100000&&70<=percentage ||to<=5000000 && from>=400000){
	printf("\nstellentcg_kerala");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60 ||to<=4500000 && from>=400000){
	printf("\nAatoonsolutions_kerala");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000 ||to<=3000000 && from>=300000){
	printf("\nNewagesyssolutions_kerala");
	printf("\n");}
	if(80<=percentage&&salary<=2000000||salary<=900000&&65<=percentage ||to<=3900000 && from>=300000){
	printf("\nwoxrotechnologysolution_kerala");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage ||to<=3500000 && from>=200000){
	printf("\nNeoito kerala");
	printf("\n");}
	if(80<=percentage&&salary<=9000000||salary<=800000&&70<=percentage ||to<=2500000 && from>=200000 ){
	printf("\nAlmeka kerala");
	printf("\n");}
	if(85<=percentage&&salary<=5000000|| salary<=500000&&percentage>=60 ||to<=2000000 && from>=400000){
	printf("\nwowmakers kerala");
	printf("\n");}
	if(80<=percentage&&salary<=1000000|| salary<=400000&&80<=percentage ||to<=1500000 && from>=100000){
	printf("\nGLInfoTech kerala");
	printf("\n");}
	if(percentage>=85&&salary<=1000000|| salary<=400000&&percentage>60 ||to<=900000 && from>=100000){
	printf("\nBrammaitsolutions_kerala");
	printf("\n");}
	if(percentage>=75&&salary<=2000000||salary<=500000&&percentage>=55 ||to<=500000 && from>=100000 ){
	printf("\nArideoceaninfoway_kerala");
	printf("\n");}
	keralac();
	return percentage;
	}
	void keralac(void)
	{
		int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	 printf("\n enter company name you want to know about:");
    gets(company);
    gets(company);
    	a=strcmpi(company,"wipro limited");
	if(a==0){
	printf("\n Welcome to wipro limited");
	printf("\n Address: 2967+7J6, Infopark Rd, Kusumagiri, PO, Kochi, Kerala");
	printf("\n It is found in 1945");
	printf("\n Rating:5.0");
	printf("\n ceo-Thierry Delaporte");
	printf("\nWipro is a global company delivering innovation-led strategy, technology, and business consulting services.");
	printf("\n Contact:04843054949");
	}
	
		a=strcmpi(company,"Ibyte solutions");
	if(a==0){
	printf("\n welcome to Ibyte solutions_kerala");
	printf("\n Address:  Sector E Hall JNI Stadium Complex, 017, Kaloor, Kerala ");
	printf("\n It is found in 2015");
	printf("\n Rating:4.9");
	printf("\n ceo-Soji Jose");
	printf("\niByte Solutions is a professional web designing and website development company in Kerala,India. Their services include web designing(UI/UX), web development, Digital Marketing, Branding and Mobile Application Development. ");
	printf("\n contact:0821696699");
	 
}
		a=strcmpi(company,"Emvigo solutions");
	if(a==0){
		printf("\n Welcome to Emvigo solutions_kerala");
	printf("\n Address: X7RR+X2X,Finance Tower, Banerji Rd, RBI Junction, Kaloor, Kochi, Kerala 682017");
	printf("\n It is found in 2012");
	printf("\n Rating:4.8");
	printf("\n ceo-Sanjay Menon");
	printf(" \n They are a young and vibrant technology solutions provider that is on a mission to bring quality changes to the common man's life.");
	printf("\n Contact:07025011144");
	}
	
		a=strcmpi(company,"codelattice digital solutions");
	if(a==0){
		printf("\n Welcome to codelattice digital solutions_kerala");
	printf("\n Address: HiLITE Business Park, Cafit Square, Kozhikode, Kerala 673014");
	printf("\n It is found in 2009");
	printf("\n Rating:4.8");
	printf("\n ceo-vijith sivadasan ");
	printf("\n it is a trusted google cloud partner. They provide various application development and shelf software products.");
	printf("\n Contact:09143100400");
	}
	
		a=strcmpi(company,"stellentcg");
	if(a==0){
	printf("\n Welcome to stellentcg_kerala");
	printf("\n Address: Grand plaza, Fort Rd, Kannur, Kerala 670001, Kannur Town, Kannur - 670001");
	printf("\n It is found in 2010");
	printf("\n Rating:4.8");
	printf("\n ceo-stellent");
   printf("\n Stellent is a result-driven digital marketing agency in Kerala. They work for people to improve their business. Using Internet technology to promote our brand. Tey will help us with digital marketing in Kerala.");
	printf("\n Contact:09847567871");
	}
	
		a=strcmpi(company,"Aatoonsolutions");
	if(a==0){
	printf("\n Welcome to Aatoonsolutions_kerala");
	printf("\n Address: Unit 1B, First Floor, Carnival Infopark Phase II Infopark Kochi P.O, Kakkand, Kochi, Kerala 682042");
	printf("\n It is found in 2015");
	printf("\n Rating:4.7");
	printf("\n ceo-Reshma Nair");
	printf("\n Aatoon Solutions LLP is a leading creative digital agency based in Cochin, Kerala-India having young, creative, talented and experienced team of IT professionals.They create innovative web and mobile applications that enable our customers to compete and win in their digital marketplace.");
	printf("\n Contact:04844044458");
	}
	
		a=strcmpi(company,"Newagesyssolutions");
	if(a==0){
	printf("\n Welcome to Newagesyssolutions_kerala");
	printf("\n Address: Phase II Carnival Infopark, Infopark SEZ Kakkanad, Kochi, Kerala 682042");
	printf("\n It is found in 1994");
	printf("\n Rating:4.7");
	printf("\nceo-deepak prakash");
	printf(" \n NewAgeSys Solutions (P) Ltd has emerged as a leading Solution Provider to Fortune 1000 Corporations; winning many awards on the way.");
	printf("\n Contact:04842983032");
	}
	
		a=strcmpi(company,"woxrotechnologysolution");
	if(a==0){
	printf("\n Welcome to woxrotechnologysolution_kerala");
	printf("\n Address: Leshore Business Park, opp. South Indian Bank, Thoppinmoola, Poothole, Thrissur, Kerala 680004");
	printf("\n It is found in 20l5");
	printf("\n Rating:4.7");
	printf("\n ceo-Irene Joseph");
	printf(" \n Woxro Technology Solution, a global software and web development company that provides full-cycle software development services, ecommerce & mobile app development servies. They focus on the creation of new values to achieve sustainable growth. As the best web development company in Kerala, Making innovations and adapting to the latest technologies and trends have been instrumental in taking Woxro to the global stage");
	printf("\n Contact:04872080212");
	}
	
		a=strcmpi(company,"Neoito");
	if(a==0){
	printf("\n Welcome to Neoito_kerala");
	printf("\n Address: Neoito Technology Center, Kuranganoor Road, Marappalam Rd, Pattom, Thiruvananthapuram, Kerala 695004 ");
	printf("\n It is found in 2014");
	printf("\n Rating:4.6");
	printf("\n ceo-Faiz mohamed haneef");
	printf("	\n  We are a top-ranked product development company that builds lightning-fast products for Fortune 500 companies, startups, and scaleups");
	printf("\n Contact:06238524482");
	}
	
		a=strcmpi(company,"Almeka_kerala");
	if(a==0){
	printf("\n Welcome to Almeka_kerala");
	printf("\n Address:ES 10, Heavenly Plaza, Vazhakkala Cochin-21 Kerala 221111 India");
	printf("\n It is found in 2005");
	printf("\n Rating:4.6");
	printf("ceo-Joby Melappilly"); 
	printf("\n ALMEKA is a well known name in the IT & Wellness industry in India and UAE. The company was founded by a group of budding professionals in 2007. Almeka is an IT services, business, web solutions, SEO and online marketing solutions organization that deliver real results to businesses globally with assured level of reliability and performance.");
	printf("\n Contact:07436813371");
	}
	
		a=strcmpi(company,"wowmakers");
	if(a==0){
	printf("\n Welcome wowmakers_kerala");
	printf("\n Address: Building No: 269AB1 Mulakkampilly Road, Near CSEZ Chittethukara, Kakkanad, Kochi, Kerala 682037");
	printf("\n It is found in :2011");
	printf("\n Rating:4.3");
	printf("\n ceo-Vivek Raghavan");
	printf("\n WowMakers is a design studio specialized in User Experience Design, Explainer Videos, and Mobile & Web Engineering.WowMakers proposes unique and innovative solutions for delightful digital experience. ");
	printf("Contact:09526047773");
	}
	
		a=strcmpi(company,"GLInfoTech");
	if(a==0){
	printf("\n Welcome to GLInfoTech_kerala");
	printf("\n Address: Top Residency, North Bus Stand, Paliyam Rd, Patturaikkal, Thrissur, Kerala 680001");
	printf("\n It is found in 2012");
	printf("\n Rating:4.2");
	printf("\n Ceo-Vijeesh Varghese");
	printf("\n GL InfoTech offers you ingenious Website development in Kerala. Apart to website development They also offer Software development and digital marketing");
	printf("\n contact:09946000449");
	}
	
		a=strcmpi(company,"Brammaitsolutions");
	if(a==0){
	printf("\n Welcome to Brammaitsolutions_kerala");
	printf("\n Address:Info Park TBC, Room No: 26B, E Sector, Jawaharlal Nehru International Stadium, Kaloor, Kochi, Kerala 682017");
	printf("\n It is found in :2010");
	printf("\n Rating:4.1");
   printf("\n ceo-ranjith");
   printf("\n Bramma IT Solutions (BITS) mainly concentrate on training than software and web based application developments. We have well experienced dedicated IT team for providing IT solutions and services ");
	printf("\n Contact:4844041999");
	}
	
		a=strcmpi(company,"Arideoceaninfoway");
	if(a==0){
	printf("\n Welcome to Arideoceaninfoway_kerala");
	printf("\n Address:Trans Avenue, Mavelipuram, Kakkanad, Kochi, Kerala. Thrikkakkara.. P.C. 682030, Edappally, Ernakulam");
	printf("\n It is found in 2000");
	printf("\n Rating:4.1");
	printf("\n ceo-Rajesh Thekkedathu ");
	printf("\n Aride Ocean Infoway, serving as a leading datacenter in Cochin, offers hosting and network infrastructure services.They focus on web hosting and server administration to become a leading vendor in the area of the same. Their business network has expanded over the major hot spots in Cochin. Apart from the IT and ITES sector,Aride ocean is serving and supporting the top level corporate companies in Cochin.");
	printf("\n Contact:18003130100");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
		printf("\n*******************************************************");
   printf("\nDo you want to search about other company:");
   printf("\n");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
}
}
int haryana(void)
{
		int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(3000000<=salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000 ||to<=8000000 && from>=300000){
	printf("\nWipro Limited, Haryana");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000 ||to<=7000000 && from>=400000){
	printf("\nTata Consultancy Services, Haryana");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000 ||to<=5000000 && from>=400000){
	printf("\nGoogle, Haryana");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=100000&&70<=percentage||to<=3000000 && from>=500000){
	printf("\nTech Mahindra, Haryana");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60||to<=3000000 && from>=400000){
	printf("\nHCL Technologies, Haryana");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000 ||to<=2500000 && from>=300000){
	printf("\nOracle, Haryana");
	printf("\n");}
	if(percentage>=80&&salary<=1000000||salary<=300000&&percentage>=60 ||to<=2000000 && from>=200000){
	printf("\nIBM India, Haryana");
	printf("\n");}
	if(percentage>=85&&salary<=900000||salary<=200000&&percentage>=55 ||to<=900000 && from>=100000){
	printf("\nAccenture, Haryana");
	printf("\n");}
	if(percentage>80&&salary<=800000||salary<=200000&&percentage>=50 ||to<=800000 && from>=100000){
	printf("\nCognizant Technology Solutions, Haryana");
	printf("\n");}
	haryanac();
	return percentage;
}
void haryanac(void)
{
	int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
		a=strcmpi(company,"Microsoft");
	if(a==0){
		printf("\nMicrosoft needs no introduction. The entire world is aware of this company and its amazing contribution in the field of computers, hardware, softwares and technology.");
        printf("\nAddress: Cyber City, 10th Floor, Tower B & C, DLF Building No.5 (Epitome, DLF Phase III, Gurugram, Haryana 122002.");
		printf("\nWebsite: www.microsoft.com");
        printf("\nCompany Description: Microsoft India markets its parent's software and services to customers across India. Its offerings include the full range of Microsoft operating systems, productivity applications, and development tools.");
		printf("\nType: Public Company");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nRating: 5.0");
		
	}
		a=strcmpi(company,"Wipro Limited");
	if(a==0){
		printf("\nWipro Limited (NYSE: WIT, BSE: 507685, NSE: WIPRO) is a leading technology services and consulting company focused on building innovative solutions that address clients� most complex digital transformation needs. Leveraging our holistic portfolio of capabilities in consulting, design, engineering, and operations, we help clients realize their boldest ambitions and build future-ready, sustainable businesses.");
        printf("\nWebsite: http://www.wipro.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
        printf("\nHeadquarters: Bangalore, Karnataka");
		printf("\nType: Public Company");
		printf("\nSpecialties: Consulting, Business Process Outsourcing, Business Application Services, Infrastructure Management, Cloud Services, Analytics and Information Management, Product and Engineering Services, Mobility, Datacentre Managed Services, and Software application management");
        printf("\nAddress: Building 2, Candor Techspace, IT/ITES,SEZ, Tikri, Sector-48, Gurgaon � 122001, Haryana");
		printf("\nPhone Number: 0124 447 0000");
		printf("\nEmail: info@wipro.com");
		printf("\nRating: 5.0");	
	}
		a=strcmpi(company,"Tata Consultancy Services");
	if(a==0){
		printf("\nThis is a global leader in IT services, consulting & business solutions with a large network of innovation and offices all across the globe.");
        printf("\nAddress: Delhi-Gurgaon Expressway Sector 74A SKYVIEW Corporate Park, Gurugram, Haryana 122004.");
		printf("\nWebsite: https://www.tcs.com/");
		printf("\nType: Public Company");
        printf("\nHeadquarters: Mumbai, Maharashtra");
		printf("\nType: Public Company");
		printf("\nSpecialties: IT Services, Business Solutions, and Consulting");
	    printf("\nRating: 4.5");
	}
		a=strcmpi(company,"Google");
	if(a==0){
		printf("\nThis internet-based company has revolutionized the way we search for information on the internet.With its mission to �to organize the world�s information and make it universally accessible and useful� Google is one of the best tech companies in the world.");
        printf("\nAddress: 691, Delhi � Jaipur Expy, Silokhera, Sector 15 Part 2, Sector 15, Gurugram, Haryana 122001.");
		printf("\nCompetencies: Vendor management, digital marketing, operations management, Analytical Skills, financial planning, process improvements and migrations, Relationship building, Customer Relationship Management (CRM), and Team Building.");
		printf("\nType: Public Company");
        printf("\nIndustries: IT Services and IT Consulting");
		printf("\n");
		printf("\nRating: 4.5");

	}
			a=strcmpi(company,"Tech Mahindra");
	if(a==0){
		printf("\nTech Mahindra represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates, and Society to Rise. We are a USD 6.0 billion company with 163,000+ professionals across 90 countries, helping 1279 global customers including Fortune 500 companies.");
        printf("\nWebsite: https://www.techmahindra.com/en-in/ ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
        printf("\nHeadquarters: Pune, Maharashtra");
		printf("\nType: Public Company");
		printf("\nSpecialties: Telecom & IT Consulting, Telecom Security Consulting, BSS /OSS, Network Technology Solutions & Services, Network Design & Engineering, Next Generation Networks, Mobility Solutions, Consulting, Solution Integration, IMS, BSG, blockchain, Artificial Intelligence, and Metaverse");
        printf("\nAddress: 805 8th floor, tower- B unitech cyber park Gurugram, Haryana, 122001 India");
		printf("\nPhone: +91 (22) 4907 3333");
		printf("\nRating: 4.5");
	}
			a=strcmpi(company,"HCL Technologies");
	if(a==0){
		printf("\nHCLTech is a global technology company, home to 225,900+ people across 60 countries, delivering industry-leading capabilities centered around digital, engineering and cloud, powered by a broad portfolio of technology services and products. ");
        printf("\nWebsite: http://www.hcltech.com");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
        printf("\nHeadquarters: Noida, Uttar Pradesh");
		printf("\nType: Public Company");
		printf("\nFounded: 1991");
        printf("\nSpecialties: Manufacturing, Aerospace & Defense, Financial Services, Telecom, Retail & CPG, Life Sciences & Healthcare, Media & Entertainment, Travel, Transportation & Logistics, Automotive, Government, Energy & Utilities, Consumer Electronics, and Healthcare");
		printf("\nAddress: Plot No. CP3, Sector 8, Techno Park, IMT Manesar, Sector 8, IMT Manesar, Gurugram, Haryana 122051, India");
        printf("\nPhone: +91 124 618 6000");
		printf("\nRating: 4.30");
		
	}
			a=strcmpi(company,"Oracle");
	if(a==0){
		printf("\nThis American tech giant is headquartered in Texas and expertise in Enterprise software, Cloud computing and Computer hardware and software systems.");
		printf("\nAddress: BLC-143 one horizon center, Golf Course Road, Harizan Colony, DLF Phase 5, Sector 54, Gurugram, Haryana 122002.");
		printf("\nCompany Description: Oracle India provides the Asian subcontinent with enterprise software for managing business data, supporting business operations, and facilitating collaboration and application development. Companies use its database management software to store and access data across numerous platforms. ");
		printf("\nWebsite: www.oracle.com ");
		printf("\nType: Public Company");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nRating: 4.25");	
	}
			a=strcmpi(company,"IBM India");
	if(a==0){
		printf("\nAt IBM, we do more than work. We create. We create as technologists, developers, and engineers. We create with our partners. We create with our competitors. If you're searching for ways to make the world work better through technology and infrastructure, software and consulting, then we want to work with you.");
        printf("\nWebsite: http//www.ibm.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
        printf("\nHeadquarters: Armonk, New York, NY");
		printf("\nType: Public Company");
		printf("\nAddress: 3rd, 4th & 6th Floor D L F Silokhera National Highway-8 Gurugram, Haryana, 122001 India");
		printf("\nSpecialties: Cloud, Mobile, Cognitive, Security, Research, Watson, Analytics, Consulting, Commerce, Experience Design, Internet of Things, Technology support, Industry solutions, Systems services, Resiliency services, Financing, and IT infrastructure");
	    printf("\nRating: 4.20");
	}
			a=strcmpi(company,"Accenture");
	if(a==0){
		printf("\nTo be committed to professionalism, be highly organized, work under strict deadline schedules with attention to detail; have excellent written and verbal communication skills. Ability to work logically and methodically to define effective processes and implement best HR policies for the human resource of the Organization.");
		printf("\nSpecialties: A generalist HR profile.Have experience from recruitments,Performance Appraisal ,Competancy mapping,job Evaluations,Decentrallising,Restructuring,Manpower planning and rationalisation.Currently expolring the universe of employee engagement activities.");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nType: Public Company");
		printf("\nAddress: 1st Floor, Tower B & C, Building No. 8, Dlf Cyber City Phase II, Gurugram, Haryana, India, 122002");
		printf("\nContact:+911244520600\n+911244520001");
		printf("\nRating: 4.0");
	}
			a=strcmpi(company,"Cognizant Technology Solutions");
	if(a==0){
		printf("\nCognizant (Nasdaq-100: CTSH) engineers modern businesses. We help our clients modernize technology, reimagine processes and transform experiences so they can stay ahead in our fast-changing world. Together, we�re improving everyday life. See how at www.cognizant.com or @cognizant.");
		printf("\nWebsite: https:www.cognizant.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Teaneck, New Jersey");
		printf("\nType: Public Company");
		printf("\nSpecialties: Interactive, Intelligent Process Automation, Digital Engineering, Industry & Platform Solutions, Internet of Things, Artificial Intelligence, Cloud, Data , Healthcare, Banking, Finance , Fintech, Manufacturing, Retail, Technology , and Salesforce");
	    printf("\nRating: 4.0");
	}
     	printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	printf("\n*********************************************************");
	printf("\nDo you want to search about other company:");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
	
}
}
int karnataka(void)
 {
   	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000 ||to<=4300000 && from>=900000){
	printf(" \nInfosys Limited");
	printf("\n");}
	if(salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000 ||to<=2000000 && from>=300000){
	printf("\nWipro Limited");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000 ||to<=9000000 && from>=1000000){
	printf("\nTata Consultancy Services Limited");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000 ||to<=5700000 && from>=2000000){
	printf("\nHCL Technologies Limited");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=100000&&70<=percentage ||to<=4000000 && from>=100000){
	printf("\nTech Mahindra Limited");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60 ||to<=3000000 && from>=500000){
	printf("\nMindtree Limited");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000 ||to<=3000000 && from>=300000){
	printf("\nMphasis Limited");
	printf("\n");}
	if(80<=percentage&&salary<=2000000||salary<=900000&&65<=percentage ||to<=2000000 && from>=900000){
	printf("\nL&T Infotech Limited");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage ||to<=5000000 && from>=400000){
	printf("\nSonata Software Limited");
	printf("\n");}
	if(80<=percentage&&salary<=9000000||salary<=800000&&70<=percentage  ||to<=9000000 && from>=800000){
	printf("\nLiferay Inc");
	printf("\n");}
	if(85<=percentage&&salary<=5000000|| salary<=500000&&percentage>=60 ||to<=5000000 && from>=400000){
	printf("\nTally Solutions Private Limited");
	printf("\n");}
	if(80<=percentage&&salary<=1000000|| salary<=400000&&80<=percentage ||to<=1000000 && from>=400000){
	printf("\nITC Infotech India Limited");
	printf("\n");}
	if(percentage>=85&&salary<=1000000|| salary<=400000&&percentage>=60 ||to<=1000000 && from>=400000){
	printf("\nCapgemini Technology Services India Limited");
	printf("\n");}
	if(percentage>=75&&salary<=2000000||salary<=600000&&percentage>=55  ||to<=2000000 && from>=400000){
	printf("\nSubex Limited");
	printf("\n");}
	if(percentage>=90&&salary<=5000000||salary<=500000&&percentage>=60 ||to<=5000000 && from>=500000){
	printf("\nAccolite Software India Private Limited");
	printf("\n");}
	karnatakac();
	return percentage;
	}
	void karnatakac(void)
	{
		int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
    a=strcmpi(company,"Infosys Limited");
    if(a==0)
    {
   	printf("\nInfosys Limited,karnataka :");
   	printf("\nCompany Description: Infosys is a leading provider of consulting, technology, outsourcing and next-generation digital services, enabling clients around the world to create and execute strategies for their digital transformation. The company also provides digital marketing, artificial intelligence, automation, analytics, engineering services, and Internet of Things services among others. Its subsidiary Infosys BPM provides business process outsourcing services. Infosys makes almost all of its sales overseas, with North America accounting for more than 60% of the total. Key industries served by the company are financial services, insurance, manufacturing, telecom, retail, and consumer goods.");
	printf("\nAddress:Neralu, #1/2 (1878), 11th Main,39th Cross, 4th T Block, Jayanagar,Bangalore 560011, Karnataka, India");
	printf("\nWebsite: www.infosys.com ");
	printf("\n$13.95 billion\nSales Growth: 20.28%\nNet Income Growth: 13.39%\nAssets: $15,555 Fiscal");
	printf("\nTel: +91-80-26534653 / 41261700");
	printf("\nFax: +91-80-41032140");
	printf("\nEmail: foundation@infosys.com");
	printf("\nsocial:infosys_limited");
	printf("\nRating: 5.00");
	}
	a=strcmpi(company,"Wipro Limited");
	if(a==0)
	{
	    printf("\nCompany Description: Wipro is a leading global information technology, consulting and business process services company. It provides digital strategy, customer centric design, consulting, infrastructure services, business process services, research and development, cloud, mobility and advanced analytics and product engineering for customers around the world. Operating in some 55 countries, the company generates about 60% of its revenue from the Americas (largely the US). Wipro offers services to companies in a wide range of industries including aerospace and defense, automotive, banking, communications, electronics, construction, healthcare, pharmaceuticals, retail, and oil, and gas. In 2021, Wipro acquired Capco for approximately $1.45 billion.");
		printf("\nAddress: Doddakannelli,Sarjapur Road,Bengaluru 560035");
		printf("\nWebsite: www.wipro.com ");
		printf("\nRevenue: $10.62 billion\nSales Growth: 27.69%\nNet Income Growth: 13.2%\nAssets: $1.08 million");
		printf("\nWebsite: www.wipro.com ");
		printf("\nFax: +91 80 28440256");
		printf("\nType: Headquarters\nYear established:	1945");
		printf("\nRating: 5.00");	
	}
	a=strcmpi(company,"Tata Consultancy Services Limited");
	if(a==0){
		printf("\nCompany Description: Registered in 2012 , tata consultancy services has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress: ABHILASH BUILDING, PLOT NO. 96 EP-IP INDUSTRIAL AREA, WHITEFIELD ROAD Bengaluru, Karnataka, 560066 India");
		printf("\nWebsite: www.tcs.com ");
		printf("\nTel: 08067242000");
		printf("\nRating: 4.5");
		}
		a=strcmpi(company,"HCL Technologies Limited");
	if(a==0){
		printf("\nAddress: 6 6 690 5hosur Gold Hill Bommanahalli Bengaluru, Karnataka, 560068 India");
	    printf("\nWebsite: www.hcltech.com");
		printf("\nPhone Number:	080678 10000");
		printf("\nRating: 4.0");
	}
		a=strcmpi(company,"Tech Mahindra Limited");
	if(a==0){
		printf("\nCompany Description: Tech Mahindra represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
		printf("\nAddress: Plot No.45 - 47, KIADB Industrial Area, Phase - II, Electronic City, Hosur Main Road Bengaluru, Karnataka, 560100 India");
		printf("\nWebsite: www.techmahindra.com");
		printf("\nPhone:+ 91 80 67807777");
		printf("\nRating: 3.7");
	}
		a=strcmpi(company,"Mindtree Limited");
	if(a==0){
		printf("\nAddress: Global Village, RVCE Post, Mysore Road, Bengaluru, Karnataka, 560059 India");
		printf("\nContact Number: 91 80 67064000");
		printf("\nContact Email: info@mindtree.com");
		printf("\nWebsite: www.mindtree.com ");
		printf("\nClass of Company: Public");
		printf("\nRating: 3.7");
	}
		a=strcmpi(company,"Mphasis Limited");
	if(a==0){
		printf("\nCompany Description: MphasiS provides consulting, IT and software development, and business process outsourcing (BPO) services to clients around the world. The company's offerings include application development and maintenance; outsourced IT services (including management of networks, data centers, integration and engineering, security systems, and workplace computer systems).");
		printf("\nAddress: Mphasis LimitedBagmane Laurel, 1st Floor, Tower A, Bagmane Technology Park,C V Raman Nagar, Bangalore 560 093, ");
		printf("\nRevenue: $1.61 billion\nSales Growth: 23.03%\nNet Income Growth: 17.59%\nAssets: $107,561");
		printf("\nTel: +91 080 4004 4444");
		printf("\nFax: +91 080 4004 9999");
		printf("\nRating: 3.5");
		}
		a=strcmpi(company,"L&T Infotech Limited");
	if(a==0){
		printf("\nCompany Description: LTI (NSE: LTI) is a global technology consulting and digital solutions Company helping more than 420 clients succeed in a converging world.");
		printf("\nAddress: L&T Special Economic Zone, Mysuru Campus, Plot No. 324-330, KIADB Industrial Area, Hebbal - Hootagalli.Mysuru, Karnataka 570018India");
		printf("\nTel: +91 22 67525656");
		printf("\nFax: +91 22 67525858");
		printf("\nEmail: info@ltts.com");
		printf("\nRating: 3.5");
	}
		a=strcmpi(company,"Sonata Software Limited");
	if(a==0){
		printf("\nCompany Description: Sonata Software Limited is a leading Modernization and digital engineering company, headquartered in Bangalore. Sonata provides modernization services using its proprietary Platformation� approach. It specializes in cloud and data modernization, Microsoft Dynamics Modernization, Digital contact center setup and management, managed cloud services and digital transformation services.");
		printf("\nAddress: 1/4, APS Trust Building, Bull Temple Road, N. R. ColonyBangalore Karnataka 560 004 India");
		printf("\nEmail: @sonata-software.com");
		printf("\nTel: +91-80-6778 1996");
		printf("\nRating: 3.5");
		}
		a=strcmpi(company,"Liferay Inc");
	if(a==0){
		printf("\nAddress: 3rd Floor, Centre Point, Plot No. 26A, Electronics City Phase 1Hosur Road, Bengaluru Karnataka - 560100 India");
		printf("\nWebsite: www.liferay.com");
		printf("\nTel: +91 080 4544 5445");
		printf("\nRating: 3.5");
	}
		a=strcmpi(company,"Tally Solutions Private Limited");
	if(a==0){
		printf("\nCompany Description: We are a technology & innovation company.Delivering business software for Small and Medium Businesses (SMBs) is our passion.What sets a company apart is as much in its DNA as its achievements.");
		printf("\nAddress: 331-336,Raheja Arcade,Koramangala, Bangalore - 560 095.");
		printf("\nTel: +918067582559");
		printf("\nDate of Incorporation: 08 November 1991");
		printf("\nEmail ID: compliance@tallysolutions.com");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"ITC Infotech India Limited");
	if(a==0){
		printf("\nCompany Description: ITC Infotech is a leading global technology services and solutions provider, led by Business and Technology Consulting. ITC Infotech provides business-friendly solutions to help clients succeed and be future-ready, by seamlessly bringing together digital expertise, strong industry speci?c alliances and the unique ability to leverage deep domain expertise from ITC Group businesses.");
		printf("\nAddress: No.18, Banaswadi Main Road, Maruthiseva Nagar, Bengaluru � 560005, India");
		printf("\nPhone: +91 80 2298 8331-37");
		printf("\nEmail ID: Itcinfotech.Bengaluru@Itcinfotech.com");
		printf("\nBranches:Kolkata\nPune\nGurugram");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"Capgemini Technology Services India Limited");
	if(a==0){
		printf("\nCompany Description: As a leading strategic partner to companies around the world, we have leveraged technology to enable business transformation for more than 50 years. We address the entire breadth of business needs, from strategy and design to managing operations. To do this, we draw on deep industry expertise and a command of the fast-evolving fields of cloud, data artificial intelligence, connectivity, software, digital engineering, and platforms.");
		printf("\nAddress: Divyasree TechPark SEZ (B4, B5, A5 & A6) IT/ITES, Doddanakundi Post Kundalahalli, Whitefield, Bengaluru, Karnataka� 560037");
		printf("\nPhone: 080 6656 7000");
		printf("\nBranches: Gurugram\nHyderabad\nChennai\nGandhinagar\nCoimbatoreKolkata\nMumbai\nNoida\nPune/nTrichy");
		printf("\nRating: 4.0");
	}
	a=strcmpi(company,"Subex Limited");
	if(a==0){
		printf("\nCompany Description: Subex is a pioneer in the space of Digital Trust, providing solutions for 75% of the world�s top 50 telcos. Founded in 1992, the year when the video-telephone was launched, we have been part of the evolution of mobile technology. Today, we are consultants to global telecom carriers for operational excellence and business transformation by driving new revenue models, enhancing the customer experience and optimizing the enterprise.");
		printf("\nAddress: Pritech Park,SEZ Block -09, 4th Floor B Wing Survey No. 51 to 64/4 Outer Ring Road, Bellandur Village Varthur, Hobli, Bengaluru, Karnataka 560103, India");
		printf("\nTel: +91 80 37451377");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"Accolite Software India Private Limited");
	if(a==0){
		printf("\nCompany Description: Accolite Digital is an innovative, best-in-class digital transformation services provider, successfully delivering design-driven complex digital transformation initiatives to Fortune 500 clients. ");
		printf("\nAddress: 2nd Floor, Umiya Business Bay, Tower 1, Cessna Business Park, Marathahalli-Sarjapur, Outer Ring RoadBengaluru - 560103");
		printf("\nTel: +91 80 6782 1234");
		printf("\nBranches: Gurugram\nHyderabad");
		printf("\nRating: 3.5");
		printf("\n");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	printf("\n*******************************************************");
   printf("\nDo you want to search about other company:");
   printf("\n");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
	}
	}
int sikkim(void)
 {
  	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
		if(percentage>=90&&salary<=7000000 || 65<=percentage&&salary<=4000000 ||to<=7000000 && from>=400000){
	printf("\n cydes technology-sikkim");
	printf("\n");}
	if(90<=percentage&&salary<=5000000 || salary<=100000&&70<=percentage ||to<=5000000 && from>=100000){
	printf("\n  Oceverse Infotech Pvt. Ltd-sikkim ");
	printf("\n");}
	if(80<=percentage&&salary<=2000000||salary<=900000&&60<=percentage ||to<=2000000 && from>=900000){
	printf("\n Senigma Tech Pvt Ltd-sikkim");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage ||to<=5000000 && from>=400000){
	printf("\n Bolds innovation pvt ltd-sikkim");
	printf("\n");}
	if(80<=percentage&&salary<=9000000||salary<=800000&&70<=percentage  ||to<=9000000 && from>=800000){
	printf("\n Sikko-sikkim ");
	printf("\n");}
	if(85<=percentage&&salary<=5000000|| salary<=500000&&percentage>=60 ||to<=5000000 && from>=500000){
	printf("\n Netspeg solutions-sikkim");
	printf("\n");}
	if(80<=percentage&&salary<=1000000|| salary<=400000&&80<=percentage ||to<=1000000 && from>=400000){
	printf("\n Techhub technology solutions-sikkim ");
	printf("\n");}
	if(percentage>=85&&salary<=1000000|| salary<=400000&&percentage>60 ||to<=1000000 && from>=900000){
	printf("\n Binary solutions-sikkim ");
	printf("\n");}
	if(percentage>=75&&salary<=2000000||salary<=600000&&percentage>=55  ||to<=2000000 && from>=600000){
	printf("\n Demi-sikkim ");
	printf("\n");}
	if(percentage>=50&&salary<=1000000||salary<=400000&&percentage>=45 ||to<=1000000 && from>=800000 ){
	printf("\n Rumtek solutions-sikkim ");
	printf("\n");}
	sikkimc();
	return percentage;
	}
	void sikkimc(void)
{
    int a,z;
    char company[100],yes[3];
    xyz:
  	printf("\n****************************************************\n");
    printf("enter company name:");
    gets(company);
    gets(company);
   a=strcmpi(company,"Rumtek solutions");
	if(a==0){
		printf("\n Welcome to Rumtek solutions-sikkim");
		printf("\n Address: and, Shreshtha Building , Behind ,Janta Bhawan, DPH, Palzor Stadium Rd, Crossing, Gangtok, sikkim");
		printf("\n It is found in 2015 ");
		printf("\n Rating 3.6");
		printf("\n Rumtek Technologies is a Software & Web Development Company.");
		printf("\n contact: 03592 231 619");
	}
		a=strcmpi(company,"Demi");
	if(a==0){
		printf("\n Welcome to Demi");
		printf("\n Address: 2nd Floor Kundekhang Building, Tibet Rd, Arithang, Gangtok, Sikkim");
		printf("\n It is found in 2013");
		printf("\n Rating 3.9");
		printf("\n  At demi we support the growth of innovative ideas, people, process & technology across sectors such as Education, Mobility, Cloud Computing, BIGData, 3D Printing, Robotics, Biosciences, Green Technologies and Sustainable Agriculture.");
		printf("\n Contact:03592 206 369");

	}
	
		a=strcmpi(company,"Binary solutions");
	if(a==0){
		printf("\n Welcome to Binary solutions-sikkim");
		printf("\n Address:  Dewan Building, Daragown Tadong National Highway 31A, M.P.Golai, Gangtok, Sikkim");
		printf("\n It is found in 2010");
		printf("\n Rating 4.2");
		printf("\n ceo-Chand Prasad");
		printf("\n Binary Solution is your trusted partner for IT Education, Website Application Development and Maintenance, Search Engine Optimization (SEO).They apply highly impressive website design that mainly aimed on eliminating all sort of barriers to sale and improve the profits.");
		printf("\n Contact: 03592 232 587");

	}
		a=strcmpi(company,"Techhub technology solutions");
	if(a==0){
		printf("\n Welcome to Techhub technology solutions-sikkim");
		printf("\n Address: Development Area, Sungava, Gangtok, Sikkim");
		printf("\n it is found in 2012");
		printf("\n Rating 4.5");
		printf("\n Vision of the Techhub Technology Solutions is to help Organizations create and successfully manage IT & ITES operations with reduced Costs and exceptional efficiency. We�ll help you brace your network for higher volumes of communications.");
		printf("\n contact: 097355 04222");
	}
		a=strcmpi(company,"Netspeg solutions");
	if(a==0){
		printf("\n Welcome to Netspeg solutions-sikkim");
		printf("\n Address: Near Sikkim Jewels, NH 31A, Top Floor(Renault Showroom), Tadong, Gangtok, Sikkim");
		printf("\n It is found in 2015 ");
		printf("\n Rating 4.7");
		printf("\n ceo-Karma Bhutia");
		printf("\n Netspeq offers leading edge technology support for catering the needs of the modern world enterprise");
		printf("\n Contact: 03592 231 664");
	}
		a=strcmpi(company,"Sikko");
	if(a==0){
		printf("\n Welcome to Sikko-sikkim");
		printf("\n Address: beside PHC, Melli, Sikkim ");
		printf("\n It is found in 2017");
		printf("\n Rating 4.8");
		printf("\n SIKKCO is a global software development company based in the great Himalayas and operations in Sikkim, Switzerland, US, Canada & expanding rapidly.");
		printf("\n Contact:076026 60737");
	}
		a=strcmpi(company,"Bolds innovation pvt ltd");
	if(a==0){
		printf("\n welcome to Bolds innovation pvt ltd-sikkim");
		printf("\n Address: Software Technology Parks of India Old Sikkim Jewels building, NH10, Tadong, Gangtok, Sikkim ");
		printf("\n It is found in 2020");
		printf("\n Rating 4.8");
		printf("\n ceo-Sudarshan Lawati");
		printf("\n We are a knowledge driven Company catering clients with world class IT services and solutions across multiple industry verticals.");
		printf("\n contact:074279 95842");
	}
		a=strcmpi(company,"Senigma Tech Pvt Ltd");
	if(a==0){
		printf("\n Welcome to Senigma Tech Pvt Ltd-sikkim");
		printf("\n Address: Apatan Niwas, Church Rd, Arithang, Gangtok, Sikkim ");
		printf("\n It is found in 2018");
		printf("\n Rating 4.9");
		printf("\n ceo-MAYANK THAKUR");
		printf("\n Senigma Tech Private Limited is one of the fastest growing Information Technology Company");
		printf("\n Contact:080013 84560");
	}
		a=strcmpi(company,"Oceverse Infotech Pvt. Ltd");
	if(a==0){
		printf("\n Welcome to Oceverse Infotech Pvt. Ltd-sikkim");
		printf("\n Address: NAMTHANG, Gangtok, Sikkim");
		printf("\n It is found in 2018");
		printf("\n Rating 5.0");
		printf("\n ceo-Om Kumar Gurung and Suzanne Gurung");
		printf("\n Computer support and services in Namthang, Sikkim.");
		printf("\n Contact:091013 87562");
	}
		a=strcmpi(company,"cydes technology");
	if(a==0){
		printf("\n Welcome to cydes technology-sikkim");
		printf("\n Address: Indira Bypass Rd, Vishal Gaon, Gangtok, Sikkim");
		printf("\n It is found in 2011");
		printf("\n Rating 5.0");
		printf("\n Cydes is a collective of professionals from the fields of technology, design and communication. They held each of their specializations at the intersection of consumer technologies to build solutions for the digital economy.");
		printf("\n One stop destination for your design, technology & marketing needs.");	
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
		printf("\n*******************************************************");
   printf("\nDo you want to search about other company:");
   printf("\n");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
		}

 }
int uttarkhand(void)
 {
  	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>=85||75<=percentage &&salary<=3000000 ||to<=4300000 && from>=500000){
	printf(" \n Rubicoitprivatelimited_uttarkhand");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || percentage>=65&&salary<=1000000 ||to<=7000000 && from>=600000){
	printf("\n CupCubeTechnology_uttarkhand");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=200000&&70<=percentage ||to<=4000000 && from>=400000){
	printf("\n SunriseITSolutions_uttarkhand");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000 ||to<=3000000 && from>=200000){
	printf("\n WITDS_WorldITDimensionalSolutions_uttarkhand");
	printf("\n");}
	if(80<=percentage&&salary<=2000000||salary<=900000&&65<=percentage ||to<=2000000 && from>=600000){
	printf("\n FylfotSoftwarepvtltd_uttarkhand");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage ||to<=3000000 && from>=350000){
	printf("\n cynoteckTechnologySolutionsPvtLtd_uttarkhand");
	printf("\n");}
	if(80<=percentage&&salary<=9000000||salary<=800000&&70<=percentage  ||to<=2500000 && from>250000){
	printf("\n EbizonDigitalPvtLtd_uttarkhand");
	printf("\n");}
	if(85<=percentage&&salary<=5000000|| salary<=500000&&percentage>=60 ||to<=1500000 && from>=200000){
	printf("\n Evontechnologies_uttarkhand");
	printf("\n");}
	if(80<=percentage&&salary<=1000000|| salary<=400000&&80<=percentage ||to<=1000000 && from>=400000){
	printf("\n smartDataEnterprisesLtd_uttarkhand ");
	printf("\n");}
	if(percentage>=85&&salary<=1000000|| salary<=400000&&percentage>60 ||to<=1500000 && from>=200000){
	printf("\n SoarlogicInformationTechnologiesPvtLtd_uttarkhand");
	printf("\n");}
	if(percentage>=75&&salary<=2000000||salary<=600000&&percentage>=55  ||to<=1000000 && from>=350000){
	printf("\n DemystifyItSolutionsPvtLtd_uttarkhand");
	printf("\n");}
	uttarkhandc();
	return percentage;
	}
	void uttarkhandc(void)
		{
		int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
		a=strcmpi(company,"Rubicoitprivatelimited");
	if(a==0){
	printf("\n Welcome to Rubicoitprivatelimited_uttarkhand");
	printf("\n Address: Plot No. 19, Sidcul Bypass Rd, Integrated Industrial Estate, Sector 12, BHEL Township, Haridwar, Uttarakhand ");
	printf("\n It is found in 2003");
	printf("\n Rating:5.0");
	printf("\n ceo-Stan G");
	printf("\nRubico IT is a Uttarakhand based IT company. They offer web design & development, internet marketing, iOS and Android application development services.");
	printf("\n Contact:07017303252");
	}
	
		a=strcmpi(company,"CupCubeTechnology");
	if(a==0){
		printf("\n Welcome to CupCubeTechnology_uttarkhand");
		printf("\n Address: uphalda, near suzuki show room, Srinagar, Uttarakhand 246174");
	   printf("\n It is found in 2012");
	   printf("\n Rating:5.0");
	   printf("\n ceo-anil butola");
		printf("\nCupCube Technology is a Best IT company in Uttarakhand. They offer web design & development, iOS and Android application development services.");
		printf("\n Contact:09520216187");
	}
		a=strcmpi(company,"SunriseITSolutions");
	if(a==0){
		printf("\n Welcome to SunriseITSolutions_uttarkhand");
		printf("\nAddress: 12 Kalyani View, opposite Hotel Royal, Rudrapur, Uttarakhand");
	   printf("\n It is found in 2013");
	   printf("\n Rating:4.9");
    	printf("\nceo-naresh pise");
		 printf("\nSunrise IT Solutions is a design house, with a new vision in graphic & web designing, dedicated to creating distinctive, modern & innovative graphic and web designing.");
		printf("\n Contact: 09410777557");
	}
		a=strcmpi(company,"WITDS_WorldITDimensionalSolutions");
	if(a==0){
		printf("\n welcome to WITDS_WorldITDimensionalSolutions_uttarkhand");
		printf("\n Address: #203F, Doon Express Business Park Saharanpur, Road, Dehradun, Uttarakhan");
	   printf("\n It is found in 2015");
	   printf("\n Rating:4.81");
	   printf("\n WITDS is total IT solution Company catering to the business and development demands of global as well as the domestic clients.WITDS has been formed to meet the never ending demand in increasing of Software market. The company mainly focuses on Designing and Development of software and websites by using all the latest technologies.");
		printf("\n Contact:07983182649");
	}
		a=strcmpi(company,"FylfotSoftwarepvtltd");
	if(a==0){
		printf("\n Welcome to FylfotSoftwarepvtltd_uttarkhand");
	   printf("\n Address:Etash block,sandhu center,clement town,near MDDA office,deharadun,uttarkhand");
	   printf("\n It is found in 1997");
	   printf("\n Rating:4.8");
	   printf("\n ceo-abhinav garg");
		printf("\n Fylfot Software was found with a simple objective to become innovative IT solution provider, for fast growing SME Business Enterprises. To achieve their objective they firmly believe that two things are essential - Quality people and Quality process.");
		printf("\n contact: 07895624082");
	}
	
		a=strcmpi(company,"cynoteckTechnologySolutionsPvtLtd");
	if(a==0){
	printf("\n Welcome to cynoteckTechnologySolutionsPvtLtd_uttarkhand");
	printf("\n Address: A-4, Sahastradhara Rd, Doon IT Park, Danda Lakhond, Dehradun, Uttarakhand");
	printf("\n It is found in :2013");
	printf("\n Rating:4.6");
	printf("\nceo-udit handa");
	printf("\n Their core philosophy and endeavor to create optimum business-focused solutions.");
   printf("\n Contact:01352608366");
	}
	
		a=strcmpi(company,"EbizonDigitalPvtLtd");
	if(a==0){
		printf("\n Welcome to EbizonDigitalPvtLtd_uttarkhand");
		printf("\n Address: IT Park, Plot 21, SIIDCUL, Sahastradhara Rd, Dehradun, Uttarakhand 248001");
	   printf("\n It is found in 2020");
	   printf("\n Rating:4.4");
	   printf("\nceo-Sudeep goyal");
		printf("\nEbizON is a great place to work because every day provides an opportunity to learn something new, to mentor and to be mentored, and to help clients achieve their goals.");	
		printf("\n Contact:01204518893");
	}
	
		a=strcmpi(company,"Evontechnologies");
	if(a==0){
	   printf("\n Welcome to Evontechnologies_uttarkhand");
		printf("\n Address: A-5, IT Park, Sahastradhara Rd, Dehradun, Uttarakhand 248001");
	   printf("\n It is found in 2006");
	   printf("\n Rating:4.3");
    	printf("\n ceo-vijendra chauhan");
	   printf("\n As an IT/software company that believes in the power of technology to shape lives, Evon calls itself a collective of �technologists�. And to create a platform for their passion, by providing top-quality software consulting and development services.");
		printf("\n Contact:08266041801");
	}
	
		a=strcmpi(company,"smartDataEnterprisesLtd");
	if(a==0){
		printf("\n Welcome to smartDataEnterprisesLtd_uttarkhand");
		printf("\n Address:Jyoti Palace, Sahastradhara Rd, Dehradun, Uttarakhand 248001");
	   printf("\n It is found in 1996");
	   printf("\n Rating:4.1 ");
	   printf("\n ceo-sanjay tiwari");
	   printf("\nsmartData is a US-based custom software development company with a 1:5 ratio of business consultants to technology experts. Having developed 8500+ applications smartData continues to deliver in the global market");
		printf("\n contact:01352781880");
	}
	
		a=strcmpi(company,"SoarlogicInformationTechnologiesPvtLtd");
	if(a==0){
		printf("\n Welcome to SoarlogicInformationTechnologiesPvtLtd_uttarkhand");
	   printf("\n Address: IT Park Sahastradhara Raod, Hall No - 7, Software Technology Parks of India (STPI), Dehradun, Uttarakhand");
   	printf("\n It is found in 2010");
    	printf("\n Rating:4.0");
	   printf("\n ceo-anil bist");
		printf("\nsoarlogic Information Technologies Pvt Ltd is responsible for providing solutions and services related to software such as building a cyber security network.");
		printf("\n Contact:01352607929");
	}
	
	
		a=strcmpi(company,"DemystifyItSolutionsPvtLtd_uttarkhand");
	if(a==0){
	  	printf("\n Welcome to DemystifyItSolutionsPvtLtd_uttarkhand");
	   printf("\nAddress:N3, Nath Market, Red Temple,, Arya Nagar, Haridwar, Uttarakhand 249407, India");
	   printf("\n It is established in 2011");
	   printf("\n Rating:3.4");
	   printf("\n ceo-Ajay");
		printf("\nAt Demstify, provide business intgeration services and end to end intgration solutions using IBM integration products and other open source products");	
		printf("\n Contact:09971483355");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
		printf("\n*******************************************************");
   printf("\nDo you want to search about other company:");
   printf("\n");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
	}
	}
int meghalaya(void)
 {
 
 	
   	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000 ||to<=4300000 && from>=900000){
	printf(" \n Techmion solutions-Meghalaya");
	printf("\n");}
	if(salary<20000000 && percentage>=85 || 75<=percentage&&salary<=3000000 ||to<=3000000 && from>=480000){
	printf("\n MegSol | IT Solutions-Meghalaya");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60 ||to<=4500000 && from>=380000){
	printf("\n codigion-Meghalaya");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000 ||to<=3500000 && from>=270000){
	printf("\n Tech soul -Meghalaya");
	printf("\n");}
	if(80<=percentage&&salary<=2000000|| salary<=900000&&65<=percentage ||to<=4000000 && from>=430000){
	printf("\n ISSTS -Meghalaya");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage ||to<=3700000 && from>=350000){
	printf("\n Intowns solutions -Meghalaya");
	printf("\n");}
	if(85<=percentage&&salary<=5000000|| salary<=500000&&percentage>=60 ||to<=3500000 && from>=300000){
	printf("\n lewduh Techz Private Limited -Meghalaya");
	printf("\n");}
	if(percentage>=85&&salary<=1000000|| salary<=400000&&percentage>60 ||to<=2000000 && from>=200000){
	printf("\n Marak Technologies Pvt Ltd -Meghalaya");
	printf("\n");}
	if(percentage>=75&&salary<=2000000||salary<=600000&&percentage>=55 ||to<=1000000 && from>=100000 ){
	printf("\n Brihat solutions-Meghalaya");
	printf("\n");}
	meghalayac();
	return percentage;

}
void meghalayac(void)
{
    int a,z;
    char company[100],yes[3];
    xyz:
   	printf("\n****************************************************\n");
    printf("enter company name:");
    gets(company);
    gets(company);
    puts(company);
    a=strcmpi(company,"Brihat solutions");
    if(a==0)
    {
   	printf("\n Welcome to Brihat solutions-Meghalaya ");
   	printf("\n Address: 95A, Upper Mawprem, Garikhana, Shillong, Meghalaya");
   	printf("\n It is found in 2017 ");
	printf("\n rating 3.0 ");
	printf("\n ceo-THAPA SRIKANT");
	printf("\n During the tenure this company has served several eminent organizations wherein they have earned the experience, reputation and marked as qualitative service provider.");
	printf("\n Contact:07596913662 ");
	}
		a=strcmpi(company,"Marak Technologies Pvt Ltd");
	if(a==0){
		printf("\n Welcome to Marak Technologies Pvt Ltd -Meghalaya");
		printf("\n Address: Andreson Building, near Kripa Foundation, Lower, Lachumiere, Shillong, Meghalaya  ");
		printf("\n It is found in 2013 ");
		printf("\n Rating 4.1 ");
		printf("\n ceo-suraj");
		printf("\n Marak Technologies Pvt. Ltd. envisions to create a globally connected tech society that can empower people in the present and future digital era.");
		printf("\n Marak Technologies is the ultimate destination for all your technical needs related to software, mobile, and web development, at the best cost. ");
		printf("\n contact: 09051251209");
	
     	}
		a=strcmpi(company,"lewduh Techz Private Limited");
	if(a==0){
		printf("\n welcome to lewduh Techz Private Limited -Meghalaya");
		printf("\n Address: Jail Road, Police Bazar, Shillong, Meghalaya 79300 ");
		printf("\n It is found in 2018");
		printf("\n Rating 4.3");
		printf("\n ceo-Omprakash Yadav");
		printf("\n lewduh Techz Private Limited is a Private incorporated on 18 July 2018. It is classified as Non-govt company and is registered at Registrar of Companies, Shillong");
		printf("\n It is inolved in Other computer related activities [for example maintenance of websites of other firms/ creation of multimedia presentations for other firms etc.]");
		printf("\n Contact:03647960223");
	}
		a=strcmpi(company,"Intowns solutions");
	if(a==0){
		printf("\n Welcome to Intowns solutions -Meghalaya");
		printf("\n Address: Modrina Mansion, 4th Floor, Nongkynrih, Laitumkhrah, Shillong, Meghalaya 793003");
		printf("\n It is found in 2013");
		printf("\n Rating 4.7");
		printf("\n ceo-Aldon Melville Pariat Mylliem");
		printf("\n In Town Solutions is an IT based company located in Shillong, Meghalaya that deals in the development, implementation and support for Software & Web Based solutions. ");
		printf("\n Our Mission : �To foster development through the smart usage of technology by presenting and simplifying it to a form that a layman would understand, appreciate and utilize.");
	}
		a=strcmpi(company,"ISSTS");
	if(a==0){
		printf("\n welcome to ISSTS -Meghalaya");
		printf("\n Address: Bait-Us-Saad, Tripura Castle Rd, Risa Colony, Malki, Shillong, Meghalaya");
		printf("\n It is found in 2016");
		printf("\n rating 4.7");
		printf("\n ceo-Avijit Debnath");
		printf("\n ISSTS is a growing Information Technologies solution provider founded by a group of young enthusiastic entrepreneurs with a clear and broader vision inspired by their innovative thinking and passionate about providing exceptional IT solutions.");
		printf("\n contact:09366710756");
		
	}
		a=strcmpi(company,"Tech soul");
	if(a==0){
		printf("\n Welcome to Tech soul -Meghalaya");
		printf("\n Address: St. Peter Paul Road Golf Link, Polo, Near Blue Ribbons Restuarant, Shillong, Meghalaya 793001 ");
		printf("\n It is found in 2018");
		printf("\n Rating 4.8");
		printf("\n Ceo-Ajay kumar ");
		printf("\n We Deal with");
      printf("\n� Website Design & Development");
      printf("\n� User Interface Designing");
      printf("\n� Logo Designing");
      printf("\n� Banner Designing");
      printf("\n� SEO (Search Engine Optimization");
      printf("\n� Web Application Development");
      printf("\n� Mobile Website Design and Development");
		printf("\n contact: 098625 42983");
	}
		a=strcmpi(company,"codigion"); 
	if(a==0){
		printf("\n Welcome to codigion -Meghalaya");
		printf("\n Address: M. Khongsit Building, Motphran, Shillong, Meghalaya 793002");
		printf("\n It is found in 2018 ");
		printf("\n Rating 4.8");
		printf("\n ceo-Shiva Chettri");
		printf("\n Codigion is the software company in Shillong, for Consulting and Software Development.");
		printf("\n The objective of Codigion is to provide distinguished and finest services across Desktop Application Development, Mobile Application Development, Web Application Development, AI Application Development and Web Security among all the software companies in Shillong");
		printf("\n Contact:08974983144");
	}
		a=strcmpi(company,"MegSol | IT Solutions");
	if(a==0){
		printf("\n Welcome to MegSol | IT Solutions-Meghalaya");
		printf("\n Address: Mawlai Mawapkhaw, Shillong, Meghalaya ");
		printf("\n It is found in 2010");
		printf("\n Rating 4.9");
		printf("\n MegSol is an organization with world-class computer programmers working to shape things better with technologies at our disposal.");
		printf("\n With the vision of delivering astounding IT services to the industry clients, MegSol is one of the few organizations that provide a high-quality IT service");
		printf("\n contact:7005412264");

	}
	
		a=strcmpi(company,"Techmion solutions");
	if(a==0){
		printf("\n welcome to Techmion solutions-Meghalaya");
		printf("\n Address: Dreamland Arcaade, Umsohsun, Police Bazar, Shillong, Meghalaya 793002");
		printf("\n It is found in 2019");
		printf("\n Rating 5.0");
		printf("\n ceo-Vedant Kumar");
		printf("\n We are an I.T. company based on the beautiful hills of Shillong, Meghalaya. Techmion Solutions India Pvt. Limited kickstarted on Jan,19. Our mission is to provide world-class technology solutions to our client.");
		printf("\n contact:8787332917");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{	
			printf("\n*******************************************************");
   printf("\nDo you want to search about other company:");
   printf("\n");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
}
}
int uttar_pradesh(void)
{
		int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000 ||to<=5000000 && from>=400000){
	printf(" \nHCL Technologies Ltd,uttar pradesh");
	printf("\n");}
	if(3000000<=salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000 ||to<=6000000 && from>=250000){
	printf("\nTata Consultancy Services Ltd, uttar pradesh");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000 ||to<=4700000 && from>=320000){
	printf("\nTech Mahindra Ltd,uttar pradesh");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000 ||to<=7500000 && from>=300000){
	printf("\nInfosys Ltd, uttar pradesh");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=100000&&70<=percentage ||to<=6800000 && from>=100000){
	printf("\nWipro Ltd, uttar pradesh");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60 ||to<=3500000 && from>=500000){
	printf("\nIBM India Private Limited, uttar pradesh");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000 ||to<=4500000 && from>=200000){
	printf("\nCognizant Technology Solutions India Pvt Ltd, uttar pradesh");
	printf("\n");}
	if(percentage>=80&&salary<=1000000||salary<=300000&&percentage>=60 ||to<=1900000 && from>=300000){
	printf("\nNIIT Technologies Ltd, uttar pradesh");
	printf("\n");}
	if(percentage>=85&&salary<=900000||salary<=200000&&percentage>=55 ||to<=2600000 && from>=380000){
	printf("\nAccenture Solutions Private Limited, uttar pradesh");
	printf("\n");}
	if(percentage>80&&salary<=800000||salary<=200000&&percentage>=50 ||to<=1500000 && from>=120000){
	printf("\nCSC India Pvt Ltd, uttar pradesh");
	printf("\n");}
	uttar_pradeshc();
	return percentage;
}
void uttar_pradeshc(void)
{
	int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
		a=strcmpi(company,"HCL Technologies Ltd");
	if(a==0){
		printf("\nHCLTech is a global technology company, home to 225,900+ people across 60 countries, delivering industry-leading capabilities centered around digital, engineering and cloud, powered by a broad portfolio of technology services and products. We work with clients across all major verticals, providing industry solutions for Financial Services, Manufacturing, Life Sciences and Healthcare, Technology and Services, Telecom and Media, Retail and CPG and Public Services. ");
		printf("\nSpecialties: Manufacturing, Aerospace & Defense, Financial Services, Telecom, Retail & CPG, Life Sciences & Healthcare, Media & Entertainment, Travel, Transportation & Logistics, Automotive, Government, Energy & Utilities, Consumer Electronics, and Healthcare");
		printf("\nWebsite: http://www.hcltech.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Noida, Uttar Pradesh");
		printf("\nType: Public Company");
		printf("\nFounded: 1991");
		printf("\nAddress: HCL Technologies Ltd,A9,Block A,Sector 3,Noida,Uttar Pradesh");
		printf("\nPhone: +91 120 252 0917");	}
		a=strcmpi(company,"Tata Consultancy Services Ltd");
	if(a==0){
		printf("\nA part of the Tata group, India's largest multinational business group, TCS has over 500,000 of the world�s best-trained consultants in 46 countries. The company generated consolidated revenues of US $22.2 billion in the fiscal year ended March 31, 2021, and is listed on the BSE (formerly Bombay Stock Exchange) and the NSE (National Stock Exchange) in India");
		printf("\nWebsite: https://www.tcs.com/ ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Mumbai, Maharashtra");
		printf("\nType: Public Company");
		printf("\nSpecialties: IT Services and IT Consulting");
		printf("\nAddress: Okaya Center, Sec 62, Noida Uttar Pradesh, India");
		printf("\nRating: 4.5");	}
		a=strcmpi(company,"Tech Mahindra Ltd");
	if(a==0){
		printf("\nTech Mahindra represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates, and Society to Rise. We are a USD 6.0 billion company with 163,000+ professionals across 90 countries, helping 1279 global customers including Fortune 500 companies.");
		printf("\nWebsite: https://www.techmahindra.com/en-in/ ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nType: Public Company");
		printf("\nHeadquarters:Pune, Maharashtra");
		printf("\nSpecialties: Telecom & IT Consulting, Telecom Security Consulting, BSS /OSS, Network Technology Solutions & Services, Network Design & Engineering, Next Generation Networks, Mobility Solutions, Consulting, Solution Integration, IMS, BSG, blockchain, Artificial Intelligence, and Metaverse");
		printf("\nAddress: 133/50, Kidwai Nagar, Subzi Mandai Kanpur, Uttar Pradesh, 208023 India");
		printf("\nRating: 4.45");	}
		a=strcmpi(company,"Infosys Ltd");
	if(a==0){
		printf("\nInfosys is a global leader in next-generation digital services and consulting. We enable clients in more than 50 countries to navigate their digital transformation. With over three decades of experience in managing the systems and workings of global enterprises, we expertly steer our clients through their digital journey.");
		printf("\nWebsite: https://www.infosys.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Bangalore, Karnataka");
		printf("\nType: Public Company");
		printf("\nFounded: 1981");
		printf("\nSpecialties: IT Solutions and Services, Consulting, Business Process Outsourcing, Products and Platforms, Engineering Services, Cloud Services, Artificial Intelligence, Digital, and Big Data");
		printf("\nAddress: Noida Campus Block A, Sector 85, Noida, Uttar Pradesh 201305, India");
		printf("\nRating: 4.35");	}
			a=strcmpi(company,"Wipro Ltd");
	if(a==0){
		printf("\nWipro Limited (NYSE: WIT, BSE: 507685, NSE: WIPRO) is a leading technology services and consulting company focused on building innovative solutions that address clients� most complex digital transformation needs. Leveraging our holistic portfolio of capabilities in consulting, design, engineering, and operations, we help clients realize their boldest ambitions and build future-ready, sustainable businesses.");
		printf("\nWebsite: http://www.wipro.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Bangalore, Karnataka");
		printf("\nType: Public Company");
		printf("\nAddress: Plot No 2,3,4 Knowledge Park-4 Gautam Budh Nagar,Greater Noida - 201308");
		printf("\nTel: +91 120 3360111");
		printf("\nFax:+91 120 4405002");
		printf("\nSpecialties: Consulting, Business Process Outsourcing, Business Application Services, Infrastructure Management, Cloud Services, Analytics and Information Management, Product and Engineering Services, Mobility, Datacentre Managed Services, and Software application management");
		printf("\nRating: 4.3");	}
			a=strcmpi(company,"IBM India Private Limited");
	if(a==0){
		printf("\nWe create as technologists, developers, and engineers. We create with our partners. We create with our competitors. If you're searching for ways to make the world work better through technology and infrastructure, software and consulting, then we want to work with you.");
        printf("\nWebsite: http://www.ibm.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Armonk, New York, NY");
		printf("\nType: Public Company");
		printf("\nSpecialties: Cloud, Mobile, Cognitive, Security, Research, Watson, Analytics, Consulting, Commerce, Experience Design, Internet of Things, Technology support, Industry solutions, Systems services, Resiliency services, Financing, and IT infrastructure");
		printf("\nAddress: C-19, Phase-2, Transport Nagar Lucknow, Uttar Pradesh, 226012");
		printf("\nRating: 4.1");	}
			a=strcmpi(company,"Cognizant Technology Solutions India Pvt Ltd ");
	if(a==0){
		printf("\nCognizant (Nasdaq-100: CTSH) engineers modern businesses. We help our clients modernize technology, reimagine processes and transform experiences so they can stay ahead in our fast-changing world. Together, we�re improving everyday life.");
		printf("\nWebsite: https://www.cognizant.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: New Jersey");
		printf("\nType: Public Company");
		printf("\nSpecialties: Interactive, Intelligent Process Automation, Digital Engineering, Industry & Platform Solutions, Internet of Things, Artificial Intelligence, Cloud, Data , Healthcare, Banking, Finance , Fintech, Manufacturing, Retail, Technology , and Salesforce");
		printf("\nAddress: Seaview Developers, Plot No 20 and 21, Building no 10, Ground to 5th, 9th-11th Floors, Gautam Buddha Nagar, Sector 135 Noida, Uttar Pradesh, 201301 India");
		printf("\nRating: 4.0");		}
			a=strcmpi(company,"NIIT Technologies Ltd");
	if(a==0){
		printf("\nWebsite: https://www.coforge.com/");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 5,001-10,000 employees");
		printf("\nHeadquarters: Noida, UP");
		printf("\nType: Public Company");
		printf("\nFounded: 2004");
		printf("\nSpecialties: Banking and Financial Services, Insurance, and Travel and Transportation");
		printf("\nAddress: Noida, Greater Noida, Gautam Budh Nagar, Uttar Pradesh");
		printf("\nRating: 4.0");	}
			a=strcmpi(company,"Accenture Solutions Private Limited");
	if(a==0){
		printf("\nAccenture is a global professional services company with leading capabilities in digital, cloud and security. Combining unmatched experience and specialized skills across more than 40 industries, we offer Strategy and Consulting, Technology and Operations services and Accenture Song�all powered by the world�s largest network of Advanced Technology and Intelligent Operations centers.");
		printf("\nWebsite: http://www.accenture.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Dublin 2");
		printf("\nType: Public Company");
		printf("\nSpecialties: Management Consulting, Systems Integration and Technology, Business Process Outsourcing, and Application and Infrastructure Outsourcing");
		printf("\nAddress:  Bldg. No.3, Gr. To 5th Floor,Bldg No. 9 Floor 8th to 10th, Plot 20 and 21, Sector 135, Noida, Uttar pradesh, Uttar Pradesh - 201301.");
		printf("\nPhone:+911206620000");
		printf("\nRating: 3.9");	}
			a=strcmpi(company,"CSC India Pvt Ltd");
	if(a==0){
		printf("\nEstablished in 2000 , CSC India Pvt. Ltd. has gained immense expertise in offering Computer Software Service, Erp Software Service, Software Development Service. etc. ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 201-500 employees");
		printf("\nHeadquarters: Global");
		printf("\nType: Public Company");
		printf("\nFounded: 1959");
		printf("\nAddress: Office No.A-44/45, Noida Tower, Sector 62, DLF IT Park, Noida, Uttar Pradesh, 201309, India");
		printf("\nRating: 3.8");	}
			printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	printf("\n*********************************************************");
	printf("\nDo you want to search about other company:");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;}
		}
		}
int andhra_pradesh(void)
{
	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
		if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000 ||to<=4300000 && from>=780000){
	printf(" \nTech Mahindra Ltd, Visakhapatnam");
	printf("\n");
	}
	if(3000000<=salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000 ||to<=3600000 && from>=490000){
	printf("\nHCL Technologies Ltd, Vijayawada");
	printf("\n");
	}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000 ||to<=4500000 && from>=350000){
	printf("\nWipro Ltd, Visakhapatnam");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000 ||to<=5300000 && from>=900000){
	printf("\nIBM India Pvt Ltd, Visakhapatnam");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60 ||to<=5000000 && from>=800000){
	printf("\nInfosys Ltd, Visakhapatnam");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000 ||to<=3000000 && from>=400000){
	printf("\nCognizant Technology Solutions India Pvt Ltd, Visakhapatnam");
	printf("\n");}
	if(80<=percentage&&salary<=2000000||salary<=900000&&65<=percentage ||to<=2000000 && from>=600000){
	printf("\nCapgemini Technology Services India Ltd, Visakhapatnam");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage ||to<=5000000 && from>=390000){
	printf("\nThe Verticals,Visakhapatanam");
	printf("\n");}
	if(80<=percentage&&salary<=9000000||salary<=800000&&70<=percentage ||to<=9000000 && from>=360000 ){
	printf("\nPronix IT Solutions Private Limited,vijayawada");
	printf("\n");}
	if(85<=percentage&&salary<=5000000|| salary<=500000&&percentage>=60 ||to<=2000000 && from>=240000){
	printf("\nArete IT Services Private Limited,vijayawada");
	printf("\n");}
	if(percentage>=80&&salary<=1000000||salary<=300000&&percentage>=60 ||to<=1000000 && from>=150000){
	printf("\ninSis Suite - Process Data Historian & Analytics Software,ongole");
	printf("\n");}
	if(percentage>=85&&salary<=900000||salary<=200000&&percentage>=55 ||to<=5000000 && from>=400000){
	printf("\nHappy infotech solutions,Andhra Pradesh");
	printf("\n");}
	if(percentage>80&&salary<=800000||salary<=200000&&percentage>=50 ||to<=5000000 && from>=400000){
	printf("\nPi Data Centers Private Limited,Andhra Pradesh");
	printf("\n");}
	andhra_pradeshc();
	return percentage;
}
void andhra_pradeshc(void)
{

	int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
	
	a=strcmpi(company,"Tech Mahindra Ltd");
    if(a==0)
    {
    	printf("\nTech Mahindra represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates, and Society to Rise.");
		printf("\n We are a USD 6.0 billion company with 163,000+ professionals across 90 countries, helping 1279 global customers including Fortune 500 companies.");
		printf("\nTech Mahindra is a part of the Mahindra Group, founded in 1945, one of the largest and most admired multinational federation of companies with 260,000 employees in over 100 countries.");
		printf("\nHeadquarters: Pune, Maharashtra");
		printf("\nSpecialties: Telecom & IT Consulting, Telecom Security Consulting, BSS /OSS, Network Technology Solutions & Services, Network Design & Engineering, Next Generation Networks, Mobility Solutions, Consulting, Solution Integration, IMS, BSG, blockchain, Artificial Intelligence, and Metaverse");
		printf("\nAddress:Tower 2, Survey No 44, Satyam Junction, Road, Near Bullaiah College, New Resapuvanipalem Village, Visakhapatnam 530003");
		printf("\nCompany size: 10,001+ employees");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nWebsite: https://www.techmahindra.com/en-in/ ");
   	printf("\ncontact number:040 6693 6263");
	printf("\nrating: 5");
	}
	a=strcmpi(company,"HCL Technologies Ltd"); 
	if(a==0)
	{
	printf("\nHCLTech is a global technology company, home to 225,900+ people across 60 countries, delivering industry-leading capabilities centered around digital, engineering and cloud, powered by a broad portfolio of technology services and products. We work with clients across all major verticals, providing industry solutions for Financial Services, Manufacturing, Life Sciences and Healthcare, Technology and Services, Telecom and Media, Retail and CPG and Public Services. Consolidated revenues as of 12 months ending March 2023 totaled $12.6 billion. To learn how we can supercharge progress for you, visit hcltech.com");
		printf("Address:HCL TECHNOLOGIES LIMITED S. NO: 20/3, NH-5, KESARAPALLI VILLAGE, GANNAVARAM, Vijayawada, Andhra Pradesh 521102, India");
		printf("\nWebsite: http:www.hcltech.com ");
		printf("\nIndustries: IT Services and IT Consulting");
		printf("\nCompany size: 10,001+ employees");
		printf("\nHeadquarters: Noida, Uttar Pradesh");
		printf("\nType: Public Company");
		printf("\nFounded: 1991");
		printf("\nSpecialties: Manufacturing, Aerospace & Defense, Financial Services, Telecom, Retail & CPG, Life Sciences & Healthcare, Media & Entertainment, Travel, Transportation & Logistics, Automotive, Government, Energy & Utilities, Consumer Electronics, and Healthcare");
	}
	a=strcmpi(company,"Wipro Ltd");
	if(a==0){
	printf("\nCorporate Office\nWipro Limited\nDoddakannelli, Sarjapur Road, Bengaluru - 560035\nTel: +91 80 28440011\nFax:+91 80 2844025\n");
	printf("\nPhone: +91 40 30797979, 30970189");
	printf("\nFax: +91 40 30970700");
	printf("\naddress:50-75-23/10 Rama Talkies Road, STPI, Old TB Hospital Area, Resapuvanipalem, Visakhapatnam, Andhra Pradesh 530013, India");
	printf("\nBranches:Maharashtra\n Baroda Gujarat\n Mumbai\n Pune\n Ahmedabad Gujarat\n Chennai\nVijayawada\n Secunderabad\n KakkanadCochin\n Bengaluru\n Mysore\n Hyderabad\nKolkata\n Bhubaneswar\nHaryana\nRajasthan\nUttar Pradesh\nGurgaon\nGreater Noida\nNew Delhi");
	printf("\nRating:4.0");  
	}
		a=strcmpi(company,"IBM India Pvt Ltd");
	if(a==0){
		printf("\nAt IBM, we do more than work. We create. We create as technologists, developers, and engineers. We create with our partners. We create with our competitors. If you're searching for ways to make the world work better through technology and infrastructure, software and consulting, then we want to work with you.");
		printf("\nAddress:Address: IT Hill No.3, Pedda Rushikonda, Rushikonda, Visakhapatnam, Andhra Pradesh  530048, IN");
		printf("\nPhone: 099897 66630");
		printf("\nWebsite: http://www.ibm.com ");
		printf("\nCompany size: 10,001+ employees ");
		printf("\nHeadquarters: Armonk, New York, NY");
		printf("\nType: Public Company");
		printf("\nSpecialties: Cloud, Mobile, Cognitive, Security, Research, Watson, Analytics, Consulting, Commerce, Experience Design, Internet of Things, Technology support, Industry solutions, Systems services, Resiliency services, Financing, and IT infrastructure");
		printf("\nrating: 4.5");
	}
		a=strcmpi(company,"Infosys Ltd");
	if(a==0){
	printf("\nMain Dc�s branches:\nBanglore DC / Bangalore Branch\nBhuvaneshwar DC\nChandigarh DC\nChennai DC:Chennai SEZ � Mahindra City, Chennai STP\nGurgaon DC\nHyderabad DC�s:Hyderabad SEZ � Largest DC, Hyderabad STP\nJaipur DC\nMangalore DC�s:Mangalore SEZ, Mangalore STP � Very Small\nInfosys Mysore DC\nPune DC�s:Pune Phase 1, Pune Phase 2 � Largest in Pune, Pune Phase 3\nTrivandrum DC");
		printf("\nAddress:48-20-84, 1st Floor, Dondaparthy Junction, Mandavari Street, Opp Siddi Vinayaka Temple, Donda Pathy Main Road, Visakhapatnam, Andhra Pradesh 530016");
		printf("\nContact number:040 6642 0000");
		printf("\nRating:4.5");
		printf("\nWebsite:www.infosys.com");
		printf("\nsocial:infosys_limited");
		
	}
		a=strcmpi(company,"Cognizant Technology Solutions India Pvt Ltd");
	if(a==0){
	printf("\nPlace Types :Business Service");
		printf("\nAddress:Visakhapatnam");
		printf("\nCoordinate: 17.4475930143, 78.3562294209");
		printf("\nPhone:(971) 2 6430362");
		printf("\nEmail:cogizant technology@gmail.com ");
		printf("\nServices: reserve");
		printf("\nRating: 4.70");
		printf("\nSocial: facebook.com/pages /Cognizant-Technology-Solu..");
		printf("\nWebsite: www.cognizant.com");
	}
		a=strcmpi(company,"Capgemini Technology Services India Ltd");
	if(a==0){
		printf("\nAddress: Visakhapatnam Taluk of Visakhapatnam District, Andhra Pradesh, 530005");
		printf("\nCorporate Identity Number(CIN): U85110PN1993PLC145950");
		printf("\nHead Office, Capgemini Service, Place de l��toile, 11 rue de Tilsitt, 75017 Paris, France");
		printf("\nwebsite: www.capgemini.com");
		printf("\nrating: 4");
		printf("\nphone: 8912546324 ");
		printf("\nfax: F. +33 1 47 54 50 25  ");
	}
		a=strcmpi(company,"The Verticals");
	if(a==0){
	printf("\nAddress: MVP Sector 4, Visakhapatnam, Andhra Pradesh 530017");
	printf("\nAn innovative environment, capturing the wide range of a vision to build a synergy between technology and progression, the label combines the latest technological innovations with traditional quality encryption to redefine the way we think about the future.");
	printf("\nWe are working together to bring the power of Artificial Intelligence into the fields of cyber security and business analytics.");
	printf("\nWebsite: http://theverticals.in/");
	printf("\nPhone:7330800851Phone number is 7330800851");
	printf("\nIndustry: IT Services and IT Consulting");
	printf("\nCompany size: 11-50 employees, 1 on LinkedIn \nIncludes members with current employer listed as The Verticals, including part-time roles.");
	printf("\nHeadquarters: Visakhapatnam, Andhra Pradesh");
	printf("\nFounded: 2018");
	printf("\nSpecialties: Data Analytics, Cyber Security, Artificial Intelligence, Products Development, No Cost Idea Evaluation, No Cost Website Makeover, No Cost Security Audit, Digital Marketing, SEO, SMO, SMM, PPC, Google Analytics, and Google Adsense");	
	}
		a=strcmpi(company,"Pronix IT Solutions Private Limited");
	if(a==0){
	printf("\nPronix Inc. is a purpose-led IT service provider that builds the digital solutions future of worldwide enterprises through innovation, technology, and collective knowledge.");
	printf("\nOperating since 2010, we are a global leader in next-generation digital services, IT Consulting & Staffing. Pronix is trusted by its clients to address and pilot the entire breadth of their software infrastructure needs from end-to-end IT strategy & design to smooth service transition & operations. We fuel your success by investing in diverse IT talents, passionate about delivering digital excellence and customer delight.");
	printf("\nWe leverage the following technology services:\n Digital Solutions\nApplication Development & Outsourced Tech Support\n Quality Assurance, DevOps & Cloud Automation\nUser Experience (UX Design and Development\nERP and CRM Solutions\nData Management and Integration\nIT Consulting & Talent Staffing\nIT Assessment and Advisory");
	printf("\nVisit us at www.pronixinc.com, and let�s innovate together.");
	printf("\nYouTube: https://www.youtube.com/pronixinc");
	printf("\nEmail: info@pronixinc.com");
	printf("\nPhone: +1- (732) 476 5277");
	printf("\nAddress: Door No-6-18-1, Chekkapalli Post Musunuru Mandal, Chekkapalli Krishna, Andhra Pradesh, 521213 Indias");
	
	}
		a=strcmpi(company,"Arete IT Services Private Limited");
	if(a==0){
    printf("\nSoftware Development , IOT Products Manufacturing ,Medical Coding , Pharmacovigilance");
	printf("\nWebsite: http://www.areteservices.org");
	printf("\nPhone: 9390009397");
	printf("\nIndustry: Software Development");
	printf("\nHeadquarters: Vijayawada, Andhra Pradesh");
	printf("\nFounded: 2008");
	printf("\nAddress: Tikkle Road, Vijayawada, Andhra Pradesh 520010, IN");}
			a=strcmpi(company,"inSis Suite - Process Data Historian & Analytics Software");
	if(a==0){
	printf("\nDigital Solutions provider for Manufacturing Industries / Process Industries - Key needs we meet are : \nProcess Data Analytics, \nEnergy Monitoring, \nProcess Performance Monitoring, \nRemote Asset Management, \nAutomated reporting, Dashboards, \nData Historian, \nKPI & Event Management with Notifications & Escalations, \nEquipment Performance Management\nGeoTagging based Asset Management\nOEE Based Performance Monitoring\nAvailability-based Tariff (ABT) & Energy Management System (EMS)\nRefinery performance monitoring");
	printf("\nAddress: Ongole, Andhra Pradesh.");
	printf("\nWebsite: http://www.jaajitech.com");
	printf("\nPhone: 8897698106Phone number is 8897698106");
	printf("\nIndustry: Software Development");
	printf("\nHeadquarters: Ongole, Andhra Pradesh\nFounded: 2013");
	printf("\nSpecialties: Process Data Analytics & Historian, Manufacturing Operations (MES/MOM), KPI & Event Management, Equipment Performance Management, EMS, ABT, Dashboards, Asset Monitoring, amadas, Refinery performance, OEE, Digital logbooks, and Remote Asset Management ");
	}
			a=strcmpi(company,"Happy infotech solutions");
	if(a==0){
	printf("\nAddress: Flat no-602(Pent House), Sai Surya Heights, Mangamoor Road, Opp Ongole Public School, Ongole, Andhra Pradesh 523002");
	printf("\nTraded asBSE: 532628 � NSE: 3IINFOTECH");
	printf("\nFounded: 1993");
	printf("\nNumber of employees: 4000+");
	printf("\nArea served: Worldwide");
	printf("\nRevenue: 651 crore (US$82 million) (2021)");
	printf("\nIndustry: Technology services, IT services � Outsourcing");	
	}
			a=strcmpi(company,"Pi Data Centers Private Limited");
	if(a==0){
	printf("\nPi Datacenters is a story envisioned by technocrats, led by the Founder & CEO, Mr. Kalyan Muppaneni. The vision was to redefine the customer experience while fueling customer business growth. This was backed by the mission to introduce hyperscale data centers & indigenous Multi-Cloud ecosystems to the Indian industry with intelligent and self-healing infrastructure.");
	printf("\nheadquartered in Hyderabad");	
	printf("\nAddress: Survey # 49/P, Plot no -12. IT Park, Autonagar, Mangalagiri, Andhra Pradesh 522503");
	printf("\nContact no: 0863 234 7555");
	printf("\nWebsite: pidatacenters.com");
	printf("\nPi operates out of its data centers and cloud points across Vijayawada (AP) and Kochi.");
	printf("\nPi is trusted highly for being the flag bearer of data localization and data sovereignty, coupled with world-class service quality delivered out of its 100% automated SCADA-enabled data center facilities & SDDC ecosystem. Pi is certified for ISO27001, ISO9000, ISO140001, ISO20000, ISO22301, STQC, PCI-DSS, SOC2 Type II, and HIPPA. It is also certified by SAP for HANA | Infrastructure | Hosting | Cloud Operations.");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	printf("\n*********************************************************");
	printf("\nDo you want to search about other company:");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
	
}
}
int bihar(void)
{
	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
		if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000 ||to<=4300000 && from>=670000){
	printf(" \nTata Consultancy Services, Bihar");
	printf("\n");}
	if(3000000<=salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000 ||to<=2000000 && from>=370000){
	printf("\nWipro Limited, Bihar");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000 ||to<=9000000 && from>=800000){
	printf("\nCognizant Technology Solutions, Bihar");
	printf("\n");}
	if(percentage>=80&&salary<=1000000||salary<=300000&&percentage>=60 ||to<=3000000 && from>=200000){
	printf("\nAmazon, Bihar");
	printf("\n");}
	if(percentage>=85&&salary<=900000||salary<=200000&&percentage>=55 ||to<=9000000 && from>=460000){
	printf("\nCapgemini, Bihar");
	printf("\n");}
	if(percentage>80&&salary<=800000||salary<=200000&&percentage>=50 ||to<=1000000 && from>=350000){
	printf("\nPisoft Technologies, Bihar");
	printf("\n");}
	biharc();
	return percentage;
}
void biharc(void)
{
		int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
		a=strcmpi(company,"Tata Consultancy Services");
	if(a==0){
		printf("\nWebsite: www.tcs.com/");
 		printf("\nHeadquarters: Mumbai, India");
 		printf("\nSize: 10000+ Employees");
 		printf("\nFounded: 1968");
 		printf("\nType: Company - Public (TCSN)");
 		printf("\nIndustry: Software Development");
 		printf("\nRevenue: $10+ billion (USD)");
 		printf("\nAddress: J4M3 + QQW, Patliputra Industrial Area, Patliputra Colony, Patna, Bihar 800013.");
 		printf("\nPhone: 91 612 221 9151");
		printf("\nrating: 4.5");
	}
		a=strcmpi(company,"Wipro Limited");
	if(a==0){
		printf("\nWipro Limited (NYSE: WIT, BSE: 507685, NSE: WIPRO) is a leading technology services and consulting company focused on building innovative solutions that address clients� most complex digital transformation needs. Leveraging our holistic portfolio of capabilities in consulting, design, engineering, and operations, we help clients realize their boldest ambitions and build future-ready, sustainable businesses.");
 		printf("\nWebsite: http://www.wipro.com ");
 		printf("\nIndustries: IT Services and IT Consulting");
 		printf("\nCompany size: 10,001+ employees");
 		printf("\nHeadquarters: Bangalore, Karnataka");
 		printf("\nType: Public Company");
 		printf("\nSpecialties: Consulting, Business Process Outsourcing, Business Application Services, Infrastructure Management, Cloud Services, Analytics and Information Management, Product and Engineering Services, Mobility, Datacentre Managed Services, and Software application management");
 		printf("\nAddress: MO-Ashochak, Near Patna Marbles, Hi-Tech Services, Ground Floor, NH-30 Purvi Lakshmi Nagar Patna, Bihar, 800030 India");
		printf("\nrating: 4.42");
	}
		a=strcmpi(company,"Cognizant Technology Solutions");
	if(a==0){
		printf("\nCognizant (Nasdaq-100: CTSH) engineers modern businesses. We help our clients modernize technology, reimagine processes and transform experiences so they can stay ahead in our fast-changing world. Together, we�re improving everyday life. ");
 		printf("\nWebsite: https://www.cognizant.com ");
 		printf("\nIndustries: IT Services and IT Consulting");
 		printf("\nCompany size: 10,001+ employees");
 		printf("\nHeadquarters: Teaneck, New Jersey");
 		printf("\nType: Public Company");
 		printf("\nSpecialties: Interactive, Intelligent Process Automation, Digital Engineering, Industry & Platform Solutions, Internet of Things, Artificial Intelligence, Cloud, Data , Healthcare, Banking, Finance , Fintech, Manufacturing, Retail, Technology , and Salesforce");
 		printf("\nAddress: Building No. 3,Unitech Realty Projects LimitedGround floor, IT & ITES villageSector - 48, Gurgaon � 122001");
		printf("\nrating: 4.35");
	}
		a=strcmpi(company,"Amazon");
	if(a==0){
		printf("\nAmazon is guided by four principles: customer obsession rather than competitor focus, passion for invention, commitment to operational excellence, and long-term thinking. We are driven by the excitement of building technologies, inventing products, and providing services that change lives. We embrace new ways of doing things, make decisions quickly, and are not afraid to fail. ");
 		printf("\nWebsite: https://www.aboutamazon.com/");
 		printf("\nIndustries: Software Development");
 		printf("\nCompany size: 10,001+ employees");
 		printf("\nHeadquarters: Seattle, WA");
 		printf("\nType: Public Company");
 		printf("\nSpecialties: e-Commerce, Retail, Operations, and Internet");
 		printf("\nAddress: Building No. 3,Unitech Realty Projects LimitedGround floor, IT & ITES villageSector - 48");
		printf("\nrating: 4.3");
	}
		
		a=strcmpi(company,"Capgemini");
	if(a==0){
		printf("\nCapgemini is a global leader in partnering with companies to transform and manage their business by harnessing the power of technology. The Group is guided everyday by its purpose of unleashing human energy through technology for an inclusive and sustainable future. ");
 		printf("\nWebsite: https://www.capgemini.com");
 		printf("\nIndustries: IT Services and IT Consulting");
 		printf("\nCompany size: 10,001+ employees");
 		printf("\nHeadquarters: Paris, France");
 		printf("\nType: Public Company");
 		printf("\nSpecialties: Outsourcing, Process Consulting, Package Based Solutions, Custom Solution Development, Application Management, Business Information Management, Artificial Intelligence, Business Consulting, Cloud, Digital, and Managed Services");
		printf("\nrating: 4.2");
	}
		a=strcmpi(company,"Pisoft Technologies");
	if(a==0){
 		printf("\nWebsite: https://www.pi-soft.net");
 		printf("\nIndustries: Software Development");
 		printf("\nCompany size: 2-10 employees");
 		printf("\nHeadquarters: Antalya");
 		printf("\nType: Privately Held");
		printf("\nrating: 4.0");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	printf("\n*********************************************************");
	printf("\nDo you want to search about other company:");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
	
}
}

int assam(void)
 {
  	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("\nenter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000 ||to<=5700000 && from>=900000){
	printf(" \n TechVariable");
	printf("\n");}
	if(salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000 ||to<=9000000 && from>=800000){ 
	printf("\n Accion Lab");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000 ||to<=4600000 && from>=780000){
	printf("\n Sysmax Technologies");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000 ||to<=5000000 && from>=900000){
	printf("\n Inspire Infosol");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=100000&&70<=percentage ||to<=6000000 && from>=800000){
	printf("\n GINEERSNOW ");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60 ||to<=4000000 && from>=260000){
	printf("\n Virtual Tech Ninja");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000 ||to<=5000000 && from>=400000){
	printf("\n Intellify");
	printf("\n");}
	if(80<=percentage&&salary<=2000000||salary<=900000&&65<=percentage ||to<=6000000 && from>=350000){
	printf("\n Web InfotechPro");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage ||to<=3000000 && from>=570000){
	printf("\n CueBlocks Technologies Pvt Ltd");
	printf("\n");}
	if(80<=percentage&&salary<=9000000||salary<=800000&&70<=percentage ||to<=2000000 && from>=460000 ){
	printf("\n QBurst ");
	printf("\n");}
	if(85<=percentage&&salary<=5000000|| salary<=500000&&percentage>=60 ||to<=3600000 && from>=390000){
	printf("\n LetX");
	printf("\n");}
	if(80<=percentage&&salary<=1000000|| salary<=400000&&80<=percentage ||to<=7800000 && from>=250000){
	printf("\n Zerone Microsystems Private Limited ");
	printf("\n");}
	if(percentage>=85&&salary<=1000000|| salary<=400000&&percentage>60 ||to<=7500000 && from>=200000){
	printf("\n InnoServ Digital");
	printf("\n");}
	if(percentage>=75&&salary<=2000000||salary<=400000&&percentage>=55 ||to<=3900000 && from>=150000 ){
	printf("\n  CrystalVision ");
	printf("\n");}
	if(percentage>=90&&salary<=5000000||salary<=500000&&percentage>=70 ||to<=2000000 && from>=100000 ){
	printf("\n WebXInfinity");
	printf("\n");}
	assamc();
	return percentage;
	}
void assamc(void)
	{
		int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
    a=strcmp(company,"TechVariable");
    if(a==0)
    {
   	printf("\nTechVariable :");
   	printf("\nCompany Description: TechVariable is an end-to-end custom healthcare software development company revolutionizing the delivery of user-centric quality care.");
	printf("\nAddress:  NEDFi House, G.S. Road, Christian Basti, Guwahati-781005, India");
	printf("\nWebsite: www.https://techvariable.com ");
    printf("\n$13.95 billion\nSales Growth: 20.28%\nNet Income Growth: 13.39%\nAssets: $15,555 Fiscal");
	printf("\nTel: +91-80-26534653 / 41261700");
	printf("\nFax: +6264604061");
	printf("\nEmail: info@techvariable.com");
	printf("\nsocial:TechVariable");
	printf("\nRating: 4.1");
	}
	a=strcmpi(company,"Accion Labs");
	if(a==0)
	{   printf("\n Accion Labs");
	    printf("\nCompany Description : Accion Labs is a global technology services firm with specialized focus on servicing enterprise and technology firms in the emerging technologies such as Web 2.0, SAAS, Cloud, eBusiness, Mobile, social media, open-source and BI/DW.");
		printf("\nAddress:  Pioneer Complex, 2nd Floor, Zoo Road Tinali, Guwahati-781024,india");
		printf("\nWebsite: https://www.accionlabs.com/ ");
		printf("\nRevenue: $10.62 billion\nSales Growth: 27.69%\nNet Income Growth: 13.2%\nAssets: $1.08 million");
		printf("\nEmail: ramesh.narasimhan@accionlabs.com ");
		printf("\nFax: +91 080 4249 4306");
		printf("\nRating: 4.2");	
	}
	a=strcmpi(company,"Sysmax Technologies");
	if(a==0){
		printf("\nCompany Description: Registered in 2012 , Sysmax Technologies has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress: 101S Block, Fourth Floor, Dona Planet, ABC, GS Road, Guwahati-781005,india");
	    printf("\nWebsite: http://sysmaxng.com");
	    printf("\n Email : Sysmax@technologies.com");
		printf("\nPhone Number:	+234 703 429 6916");
		printf("\nRating: 5.0");
		}
		a=strcmpi(company,"GINEERSNOW");
	if(a==0){
		printf("\nCompany Description: Registered in 2012 , GINEERSNOW Limited has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress: Rukminigaon, Guwahati-781022,india");
	    printf("\nWebsite:https://gineersnow.com");
	    printf("\n Email : GINEERSNOW@gmail.com");
		printf("\nPhone Number:	+234 703 429 6916");
		printf("\nRating: 4.0");
	}
		a=strcmpi(company,"Inspire Infosol");
	if(a==0){
		printf("\nCompany Description: Inspire Infosol represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
	    printf("\nAddress:  Apollo Clinic Building, 1st Floor, Anand Nagar Road, Six Mile, Guwahati-781022,india");
		printf("\nWebsite: https://www.inspireinfosol.com");
		printf("\n email : saritha@inspireinfosol.com");
		printf("\nPhone: 08639124626");
		printf("\nRating: 3.5");
	}
		a=strcmpi(company,"Virtual Tech Ninja");
	if(a==0){
		printf("\nCompany Description: Virtual Tech Ninja  represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
		printf("\nAddress: 1st floor, TDT Road, Near NERIM, Jayanagar, Guwahati-781023,india");
		printf("\nContact Number: 099992 60038");
		printf("\nEmail: Mayankkhanna111@gmail.com ");
		printf("\nWebsite: https://www.virtualtechninjas.com ");
		printf("\nRating: 3.8");
	}
		a=strcmpi(company,"Intellify");
	if(a==0){
		printf("\nCompany Description:Intellify, IT and software development, and business process outsourcing (BPO) services to clients around the world. The company's offerings include application development and maintenance; outsourced IT services (including management of networks, data centers, integration and engineering, security systems, and workplace computer systems).");
		printf("\nAddress:  Assam Engineering College Road, Jalukbari, Guwahati-781013,india ");
		printf("\nRevenue: $1.61 billion\nSales Growth: 23.03%\nNet Income Growth: 17.59%\nAssets: $107,561");
		printf("\nTel: +91 098230 49525");
	   	printf("\nEmail:contact@intellifysolutions.com. ");
		printf("\nWebsite: https://intellifysolutions.com/contact-us ");
		printf("\nRating: 3.5");
		}
	a=strcmpi(company,"Web InfotechPro");
	if(a==0){
		printf("\nCompany Description: Web InfotechPro is a global technology consulting and digital solutions Company helping more than 420 clients succeed in a converging world.");
		printf("\nAddress: Maligaon, Guwahati-781012,india");
		printf("\nTel: +91 063029 25097");
		printf("\nEmail: webinfotechftp@gmail.com");
		printf("\nWebsite: https://www.webinfotechgov.com ");
		printf("\nRating: 4.5");
	}
		a=strcmpi(company,"CueBlocks Technologies Pvt Ltd");
	if(a==0){
		printf("\nCompany Description: Sonata Software Limited is a leading Modernization and digital engineering company, headquartered in Bangalore. Sonata provides modernization services using its proprietary Platformation� approach. It specializes in cloud and data modernization, Microsoft Dynamics Modernization, Digital contact center setup and management, managed cloud services and digital transformation services.");
		printf("\nAddress:  West Boragaon, Guwahati-781034,india");
		printf("\nEmail: skbansalandco@gmail.com");
    	printf("\nWebsite: https://www.cueblocks.com");
		printf("\nTel: +91 099150 94372");
		printf("\nRating: 4.7");
		}
	a=strcmpi(company,"QBurst");
	if(a==0)
	{
	   	printf("\nCompany Description: We are a technology & innovation company.Delivering business software for Small and Medium Businesses (SMBs) is our passion.What sets a company apart is as much in its DNA as its achievements.");
		printf("\nAddress: Near Deepor Beel, VIP Road, Guwahati-781008,india");
		printf("\nWebsite:https://www.qburst.com");
		printf("\nEmail: bdg@qburst.com");
		printf("\nTel:  +1 (703) 652-8473");
		printf("\nRating: 4.6");
	}
	a=strcmpi(company,"LetX");
	if(a==0){
		printf("\nCompany Description: We are a technology & innovation company.Delivering business software for Small and Medium Businesses (SMBs) is our passion.What sets a company apart is as much in its DNA as its achievements.");
		printf("\nAddress: 6th Floor, Mahavir Market, Fancy Bazar, Guwahati, Assam-781001,india");
		printf("\nTel: +918067582559");
		printf("\nDate of Incorporation: 08 November 1991");
			printf("\nWebsite:https://www.letx.com");
		printf("\nEmail ID: lets@.com");
		printf("\nRating: 3.1");
	}
	a=strcmpi(company,"Zerone Microsystems Private Limited");
	if(a==0){
		printf("\nCompany Description : leading global technology services and solutions provider, led by Business and Technology Consulting. ITC Infotech provides business-friendly solutions to help clients succeed and be future-ready, by seamlessly bringing together digital expertise, strong industry speci?c alliances and the unique ability to leverage deep domain expertise from ITC Group businesses.");
		printf("\nAddress:  H.O. - 40S, R.G.Barua Road, Ambikagiri Nagar, Guwahati-781024,india");
		printf("\nPhone: +91 80 2298 8331-37");
		printf("\nEmail ID:  jbh@zup.cash");
		printf("\nWebsite:https://www.letx.com");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"InnoServ Digital");
	if(a==0){
		printf("\nCompany Description: As a leading strategic partner to companies around the world, we have leveraged technology to enable business transformation for more than 50 years. We address the entire breadth of business needs, from strategy and design to managing operations. To do this, we draw on deep industry expertise and a command of the fast-evolving fields of cloud, data artificial intelligence, connectivity, software, digital engineering, and platforms.");
		printf("\nAddress: H.O. - 40S, R.G.Barua Road, Ambikagiri Nagar, Guwahati-781024,india");
		printf("\nPhone:+91-7057702998");
		printf("\nEmail ID:  info@innoserv.co.in.");
	    printf("\nWebsite:www.innoservdigital.com");
		printf("\nRating: 4.0");
	}
	a=strcmpi(company,"CrystalVision");
	if(a==0){
		printf("\nCompany Description: Subex is a pioneer in the space of Digital Trust, providing solutions for 75% of the world�s top 50 telcos. Founded in 1992, the year when the video-telephone was launched, we have been part of the evolution of mobile technology. Today, we are consultants to global telecom carriers for operational excellence and business transformation by driving new revenue models, enhancing the customer experience and optimizing the enterprise.");
		printf("\nAddress:1st floor, Mahalaxmi Market Complex, Bhangagarh, Guwahati-781005,india");
		printf("\nTel: +91 80 37451377");
		printf("\nEmail ID:  info@crystalindustrial.in");
	    printf("\nWebsite:https://www.crystalvision.tv");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"WebXInfinity");
	if(a==0){
		printf("\nCompany Description: WebXInfinity is an innovative, best-in-class digital transformation services provider, successfully delivering design-driven complex digital transformation initiatives to Fortune 500 clients. ");
		printf("\nAddress: Sijubari, Hatigaon, Guwahati-781006,india");
		printf("\nTel: +91 80 6782 1234");
	   	printf("\nEmail ID:  xxxx@webxinfinity.com");
	    printf("\nWebsite:http://webxinfinity.com");
		printf("\nRating: 3.5");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	printf("\n*******************************************************");
   printf("\nDo you want to search about other company:");
   printf("\n");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
}
}
int tamilnadu(void)
 {
   	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000||to<=7000000 && from>=790000){
	printf(" \nInfosys Limited");
	printf("\n");}
	if(salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000||to<=6500000 && from>=900000){
	printf("\nWipro Limited");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000||to<=6000000 && from>=400000){
	printf("\nTata Consultancy Services Limited");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000||to<=5000000 && from>=990000){
	printf("\nHCL Technologies Limited");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=100000&&70<=percentage||to<=4800000 && from>=780000){
	printf("\nTech Mahindra Limited");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60||to<=4600000 && from>=700000){
	printf("\nMindtree Limited");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000||to<=3500000 && from>=670000){
	printf("\nMphasis Limited");
	printf("\n");}
	if(80<=percentage&&salary<=2000000||salary<=900000&&65<=percentage||to<=3600000 && from>=650000){
	printf("\nL&T Infotech Limited");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage||to<=5000000 && from>=600000){
	printf("\nSonata Software Limited");
	printf("\n");}
	if(80<=percentage&&salary<=9000000||salary<=800000&&70<=percentage||to<=9000000 && from>=400000 ){
	printf("\nLiferay Inc");
	printf("\n");}
	if(85<=percentage&&salary<=5000000|| salary<=500000&&percentage>=60||to<=5000000 && from>=390000){
	printf("\nTally Solutions Private Limited");
	printf("\n");}
	if(80<=percentage&&salary<=1000000|| salary<=400000&&80<=percentage||to<=1000000 && from>=340000){
	printf("\nITC Infotech India Limited");
	printf("\n");}
	if(percentage>=85&&salary<=1000000|| salary<=400000&&percentage>60||to<=2000000 && from>=100000){
	printf("\nCapgemini Technology Services India Limited");
	printf("\n");}
	if(percentage>=75&&salary<=2000000||salary<=600000&&percentage>=55 ||to<=3000000 && from>=200000){
	printf("\nSubex Limited");
	printf("\n");}
	if(percentage>=90&&salary<=5000000||salary<=500000&&percentage>=80 ||to<=1500000 && from>=150000){
	printf("\nAccolite Software India Private Limited");
	printf("\n");}
	tamilnaduc();
	return percentage;
	}
void tamilnaduc(void)
{
		int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
    a=strcmpi(company,"Infosys Limited");
    if(a==0)
    {
   	printf("\nInfosys Limited,Tamil nadu :");
   	printf("\nCompany Description: Infosys is a leading provider of consulting, technology, outsourcing and next-generation digital services, enabling clients around the world to create and execute strategies for their digital transformation. The company also provides digital marketing, artificial intelligence, automation, analytics, engineering services, and Internet of Things services among others. Its subsidiary Infosys BPM provides business process outsourcing services. Infosys makes almost all of its sales overseas, with North America accounting for more than 60% of the total. Key industries served by the company are financial services, insurance, manufacturing, telecom, retail, and consumer goods.");
	printf("\nAddress:Neralu, #1/2 (1878), 11th Main,39th Cross, 4th T Block,chennai, Tamil nadu, India");
	printf("\nWebsite: www.infosys.com ");
	printf("\n$13.95 billion\nSales Growth: 20.28%\nNet Income Growth: 13.39%\nAssets: $15,555 Fiscal");
	//printf("\nTel: +91-80-26534653 / 41261700");
	printf("\nFax: +91-80-41032140");
	printf("\nEmail: foundation@infosys.com");
	printf("\nsocial:infosys_limited");
	printf("\nRating: 5.00");
	}
	a=strcmpi(company,"Wipro Limited");
	if(a==0)
	{
	    printf("\nCompany Description: Wipro is a leading global information technology, consulting and business process services company. It provides digital strategy, customer centric design, consulting, infrastructure services, business process services, research and development, cloud, mobility and advanced analytics and product engineering for customers around the world. Operating in some 55 countries, the company generates about 60% of its revenue from the Americas (largely the US). Wipro offers services to companies in a wide range of industries including aerospace and defense, automotive, banking, communications, electronics, construction, healthcare, pharmaceuticals, retail, and oil, and gas. In 2021, Wipro acquired Capco for approximately $1.45 billion.");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nWebsite: www.wipro.com ");
		printf("\nRevenue: $10.62 billion\nSales Growth: 27.69%\nNet Income Growth: 13.2%\nAssets: $1.08 million");
		printf("\nWebsite: www.wipro.com ");
		printf("\nFax: +91 80 28440256");
		printf("\nType: Headquarters\nYear established:	1945");
		printf("\nRating: 5.00");	
	}
	a=strcmpi(company,"Tata Consultancy Services Limited");
	if(a==0){
		printf("\nCompany Description: Registered in 2012 , tata consultancy services has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nWebsite: www.tcs.com ");
		printf("\nTel: 08067242000");
		printf("\nRating: 4.5");
		}
		a=strcmpi(company,"HCL Technologies Limited");
	if(a==0){
		printf("\nCompany Description: Registered in 2012 , HCL Technologies Limited has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress: chennnai,Tamil nadu,india");
	    printf("\nWebsite: www.hcltech.com");
		printf("\nPhone Number:	080678 10000");
		printf("\nRating: 4.0");
	}
		a=strcmpi(company,"Tech Mahindra Limited");
	if(a==0){
		printf("\nCompany Description: Tech Mahindra represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
	    printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nWebsite: www.techmahindra.com");
		printf("\nPhone:+ 91 80 67807777");
		printf("\nRating: 3.7");
	}
		a=strcmpi(company,"Mindtree Limited");
	if(a==0){
		printf("\nCompany Description:Mindtree Limited  represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nContact Number: 91 80 67064000");
		printf("\nContact Email: info@mindtree.com");
		printf("\nWebsite: www.mindtree.com ");
		printf("\nClass of Company: Public");
		printf("\nRating: 3.7");
	}
		a=strcmpi(company,"Mphasis Limited");
	if(a==0){
		printf("\nCompany Description: MphasiS provides consulting, IT and software development, and business process outsourcing (BPO) services to clients around the world. The company's offerings include application development and maintenance; outsourced IT services (including management of networks, data centers, integration and engineering, security systems, and workplace computer systems).");
		printf("\nAddress: chennnai,Tamil nadu,india ");
		printf("\nRevenue: $1.61 billion\nSales Growth: 23.03%\nNet Income Growth: 17.59%\nAssets: $107,561");
		printf("\nTel: +91 080 4004 4444");
		printf("\nFax: +91 080 4004 9999");
		printf("\nRating: 3.5");
		}
		a=strcmpi(company,"L&T Infotech Limited");
	if(a==0){
		printf("\nCompany Description: LTI (NSE: LTI) is a global technology consulting and digital solutions Company helping more than 420 clients succeed in a converging world.");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nTel: +91 22 67525656");
		printf("\nFax: +91 22 67525858");
		printf("\nEmail: info@ltts.com");
		printf("\nRating: 3.5");
	}
		a=strcmpi(company,"Sonata Software Limited");
	if(a==0){
		printf("\nCompany Description: Sonata Software Limited is a leading Modernization and digital engineering company, headquartered in Bangalore. Sonata provides modernization services using its proprietary Platformation� approach. It specializes in cloud and data modernization, Microsoft Dynamics Modernization, Digital contact center setup and management, managed cloud services and digital transformation services.");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nEmail: @sonata-software.com");
		printf("\nTel: +91-80-6778 1996");
		printf("\nRating: 3.5");
		}
		a=strcmpi(company,"Liferay Inc");
	if(a==0){
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nWebsite: www.liferay.com");
		printf("\nTel: +91 080 4544 5445");
		printf("\nRating: 3.5");
	}
		a=strcmpi(company,"Tally Solutions Private Limited");
	if(a==0){
		printf("\nCompany Description: We are a technology & innovation company.Delivering business software for Small and Medium Businesses (SMBs) is our passion.What sets a company apart is as much in its DNA as its achievements.");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nTel: +918067582559");
		printf("\nDate of Incorporation: 08 November 1991");
		printf("\nEmail ID: compliance@tallysolutions.com");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"ITC Infotech India Limited");
	if(a==0){
		printf("\nCompany Description: ITC Infotech is a leading global technology services and solutions provider, led by Business and Technology Consulting. ITC Infotech provides business-friendly solutions to help clients succeed and be future-ready, by seamlessly bringing together digital expertise, strong industry speci?c alliances and the unique ability to leverage deep domain expertise from ITC Group businesses.");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nPhone: +91 80 2298 8331-37");
		printf("\nEmail ID: Itcinfotech.Bengaluru@Itcinfotech.com");
		printf("\nBranches:Kolkata\nPune\nGurugram");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"Capgemini Technology Services India Limited");
	if(a==0){
		printf("\nCompany Description: As a leading strategic partner to companies around the world, we have leveraged technology to enable business transformation for more than 50 years. We address the entire breadth of business needs, from strategy and design to managing operations. To do this, we draw on deep industry expertise and a command of the fast-evolving fields of cloud, data artificial intelligence, connectivity, software, digital engineering, and platforms.");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nPhone: 080 6656 7000");
		printf("\nBranches: Gurugram\nHyderabad\nChennai\nGandhinagar\nCoimbatoreKolkata\nMumbai\nNoida\nPune/nTrichy");
		printf("\nRating: 4.0");
	}
	a=strcmpi(company,"Subex Limited");
	if(a==0){
		printf("\nCompany Description: Subex is a pioneer in the space of Digital Trust, providing solutions for 75% of the world�s top 50 telcos. Founded in 1992, the year when the video-telephone was launched, we have been part of the evolution of mobile technology. Today, we are consultants to global telecom carriers for operational excellence and business transformation by driving new revenue models, enhancing the customer experience and optimizing the enterprise.");
		printf("\nAddress:chennnai,Tamil nadu,india");
		printf("\nTel: +91 80 37451377");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"Accolite Software India Private Limited");
	if(a==0){
		printf("\nCompany Description: Accolite Digital is an innovative, best-in-class digital transformation services provider, successfully delivering design-driven complex digital transformation initiatives to Fortune 500 clients. ");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nTel: +91 80 6782 1234");
		printf("\nBranches: Gurugram\nHyderabad");
		printf("\nRating: 3.5");
		printf("\n");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	printf("\n*******************************************************");
   printf("\nDo you want to search about other company:");
   printf("\n");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
}
}
int goa(void)
{
  	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000||to<=8000000 && from>=1000000){
	printf(" \nInfosys Limited");
	printf("\n");}
	if(salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000||to<=7900000 && from>=900000){
	printf("\nWipro Limited");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000||to<=6000000 && from>=800000){
	printf("\nTata Consultancy Services Limited");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000||to<=7200000 && from>=600000){
	printf("\nHCL Technologies Limited");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=100000&&70<=percentage||to<=6500000 && from>=500000){
	printf("\nTech Mahindra Limited");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60||to<=5000000 && from>=600000){
	printf("\nMindtree Limited");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000||to<=4500000 && from>=500000){
	printf("\nMphasis Limited");
	printf("\n");}
	if(80<=percentage&&salary<=2000000||salary<=900000&&65<=percentage||to<=4500000 && from>=490000){
	printf("\nL&T Infotech Limited");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage||to<=4000000 && from>=450000){
	printf("\nSonata Software Limited");
	printf("\n");}
	if(80<=percentage&&salary<=9000000||salary<=800000&&70<=percentage ||to<=3600000 && from>=400000){
	printf("\nLiferay Inc");
	printf("\n");}
	if(85<=percentage&&salary<=5000000|| salary<=500000&&percentage>=60||to<=3400000 && from>=300000){
	printf("\nTally Solutions Private Limited");
	printf("\n");}
	if(80<=percentage&&salary<=1000000|| salary<=400000&&80<=percentage||to<=3000000 && from>=390000){
	printf("\nITC Infotech India Limited");
	printf("\n");}
	if(percentage>=85&&salary<=1000000|| salary<=400000&&percentage>60||to<=2000000 && from>=300000){
	printf("\nCapgemini Technology Services India Limited");
	printf("\n");}
	if(percentage>=75&&salary<=2000000||salary<=600000&&percentage>=55 ||to<=2000000 && from>=200000){
	printf("\nSubex Limited");
	printf("\n");}
	if(percentage>=90&&salary<=5000000||salary<=500000&&percentage>=80 ||to<=1000000 && from>=190000){
	printf("\nAccolite Software India Private Limited");
	printf("\n");}
	goac();
	return percentage;
	}
void goac(void)
	{
			int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
    a=strcmpi(company,"Infosys Limited");
    if(a==0)
    {
   	printf("\nInfosys Limited,Goa :");
   	printf("\nCompany Description: Infosys is a leading provider of consulting, technology, outsourcing and next-generation digital services, enabling clients around the world to create and execute strategies for their digital transformation. The company also provides digital marketing, artificial intelligence, automation, analytics, engineering services, and Internet of Things services among others. Its subsidiary Infosys BPM provides business process outsourcing services. Infosys makes almost all of its sales overseas, with North America accounting for more than 60% of the total. Key industries served by the company are financial services, insurance, manufacturing, telecom, retail, and consumer goods.");
	printf("\nAddress:FWX8+6GR, A.B., Panjim - Belagavi Rd, Goa 403001, India");
	printf("\nWebsite: www.infosys.com ");
	printf("\nFax: +91-80-41032140");
	printf("\nEmail: foundation@infosys.com");
	printf("\nsocial:infosys_limited");
	printf("\nRating: 5.00");
	}
	a=strcmpi(company,"Wipro Limited");
	if(a==0)
	{
	    printf("\nCompany Description: Wipro is a leading global information technology, consulting and business process services company. It provides digital strategy, customer centric design, consulting, infrastructure services, business process services, research and development, cloud, mobility and advanced analytics and product engineering for customers around the world. Operating in some 55 countries, the company generates about 60% of its revenue from the Americas (largely the US). Wipro offers services to companies in a wide range of industries including aerospace and defense, automotive, banking, communications, electronics, construction, healthcare, pharmaceuticals, retail, and oil, and gas. In 2021, Wipro acquired Capco for approximately $1.45 billion.");
		printf("\nAddress: St Inez Road, Santa Inez, Panaji, Goa, 403001.,India");
		printf("\nWebsite: www.wipro.com ");
		printf("\nRevenue: $10.62 billion\nSales Growth: 27.69%\nNet Income Growth: 13.2%\nAssets: $1.08 million");
		printf("\nWebsite: www.wipro.com ");
		printf("\nFax: +91 80 28440256");
		printf("\nType: Headquarters\nYear established:	1945");
		printf("\nRating: 5.00");	
	}
	a=strcmpi(company,"Tata Consultancy Services Limited");
	if(a==0){
		printf("\n Tata Consultancy Services Limited");
		printf("\nCompany Description: Registered in 2012 , tata consultancy services has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress: St Inez Road, Santa Inez, Panaji, Goa, 403001.,india");
		printf("\nWebsite: www.tcs.com ");
		printf("\nTel: 08067242000");
		printf("\nRating: 4.5");
		}
		a=strcmpi(company,"HCL Technologies Limited");
	if(a==0){
		printf("\n HCL Technologies Limited ");
		printf("\nCompany Description: Registered in 2012 , HCL Technologies Limited has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress: 129, PHASE-3, VERNA INDUSTRIAL ESTATE, VERNA-GOA -403722. 30AAACH2420C1Z,india");
	    printf("\nWebsite: www.hcltech.com");
		printf("\nPhone Number:	080678 10000");
		printf("\nRating: 4.0");
	}
		a=strcmpi(company,"Tech Mahindra Limited");
	if(a==0){
		printf("\nCompany Description: Tech Mahindra represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
	    printf("\nAddress:5th Delta One Giga Space IT Park Internal Road Viman Nagar Pune Maharashtra 411014 IN, Giga Space IT Park Internal Rd, Sakore Nagar, Viman Nagar, Pune, Maharashtra 411014");
		printf("\nWebsite: www.techmahindra.com");
		printf("\nPhone:+ 91 80 67807777");
		printf("\nRating: 3.7");
	}
		a=strcmpi(company,"Mindtree Limited");
	if(a==0){
		printf("\n Mindtree Limited");
		printf("\nCompany Description:Mindtree Limited  represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
		printf("\nAddress:  Behind R V Engineering College, Global Village, Mysore Road, R V Road-560059,india");
		printf("\nContact Number: 91 80 67064000");
		printf("\nContact Email: info@mindtree.com");
		printf("\nWebsite: www.mindtree.com ");
		printf("\nClass of Company: Public");
		printf("\nRating: 3.7");
	}
		a=strcmpi(company,"Mphasis Limited");
	
	if(a==0){
		printf("\n Mphasis Limited");
		printf("\nCompany Description: MphasiS provides consulting, IT and software development, and business process outsourcing (BPO) services to clients around the world. The company's offerings include application development and maintenance; outsourced IT services (including management of networks, data centers, integration and engineering, security systems, and workplace computer systems).");
		printf("\nAddress: Suite 340, South wind Office Center D Building, 8295 Tournament Drive, Memphis, TN - 38125.,india ");
		printf("\nRevenue: $1.61 billion\nSales Growth: 23.03%\nNet Income Growth: 17.59%\nAssets: $107,561");
		printf("\nTel: +91 080 4004 4444");
		printf("\nFax: +91 080 4004 9999");
		printf("\nRating: 3.5");
		}
		a=strcmpi(company,"L&T Infotech Limited");
	if(a==0){
		printf("\n L&T Infotech Limited");
		printf("\nCompany Description: LTI (NSE: LTI) is a global technology consulting and digital solutions Company helping more than 420 clients succeed in a converging world.");
		printf("\nAddress: Shop No:F-2, First Floor, Edcon Towers, Menezes Bragan�a Rd, Ozari, Panaji, Goa 403001,india");
		printf("\nTel: +91 22 67525656");
		printf("\nFax: +91 22 67525858");
		printf("\nEmail: info@ltts.com");
		printf("\nRating: 3.5");
	}
		a=strcmpi(company,"Sonata Software Limited");
	if(a==0){
		printf("\n Sonata Software Limited");
		printf("\nCompany Description: Sonata Software Limited is a leading Modernization and digital engineering company, headquartered in Bangalore. Sonata provides modernization services using its proprietary Platformation� approach. It specializes in cloud and data modernization, Microsoft Dynamics Modernization, Digital contact center setup and management, managed cloud services and digital transformation services.");
		printf("\nAddress: Shop No:F-2, First Floor, Edcon Towers, Menezes Bragan�a Rd, Ozari, Panaji, Goa 403001,india");
		printf("\nEmail: @sonata-software.com");
		printf("\nTel: +91-80-6778 1996");
		printf("\nRating: 3.5");
		}
		a=strcmpi(company,"Liferay Inc");
	if(a==0){
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nWebsite: www.liferay.com");
		printf("\nTel: +91 080 4544 5445");
		printf("\nRating: 3.5");
	}
		a=strcmpi(company,"Tally Solutions Private Limited");
	if(a==0){
		printf("\nCompany Description: We are a technology & innovation company.Delivering business software for Small and Medium Businesses (SMBs) is our passion.What sets a company apart is as much in its DNA as its achievements.");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nTel: +918067582559");
		printf("\nDate of Incorporation: 08 November 1991");
		printf("\nEmail ID: compliance@tallysolutions.com");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"ITC Infotech India Limited");
	if(a==0){
		printf("\nCompany Description: ITC Infotech is a leading global technology services and solutions provider, led by Business and Technology Consulting. ITC Infotech provides business-friendly solutions to help clients succeed and be future-ready, by seamlessly bringing together digital expertise, strong industry speci?c alliances and the unique ability to leverage deep domain expertise from ITC Group businesses.");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nPhone: +91 80 2298 8331-37");
		printf("\nEmail ID: Itcinfotech.Bengaluru@Itcinfotech.com");
		printf("\nBranches:Kolkata\nPune\nGurugram");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"Capgemini Technology Services India Limited");
	if(a==0){
		printf("\nCompany Description: As a leading strategic partner to companies around the world, we have leveraged technology to enable business transformation for more than 50 years. We address the entire breadth of business needs, from strategy and design to managing operations. To do this, we draw on deep industry expertise and a command of the fast-evolving fields of cloud, data artificial intelligence, connectivity, software, digital engineering, and platforms.");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nPhone: 080 6656 7000");
		printf("\nBranches: Gurugram\nHyderabad\nChennai\nGandhinagar\nCoimbatoreKolkata\nMumbai\nNoida\nPune/nTrichy");
		printf("\nRating: 4.0");
	}
	a=strcmpi(company,"Subex Limited");
	if(a==0){
		printf("\nCompany Description: Subex is a pioneer in the space of Digital Trust, providing solutions for 75% of the world�s top 50 telcos. Founded in 1992, the year when the video-telephone was launched, we have been part of the evolution of mobile technology. Today, we are consultants to global telecom carriers for operational excellence and business transformation by driving new revenue models, enhancing the customer experience and optimizing the enterprise.");
		printf("\nAddress:chennnai,Tamil nadu,india");
		printf("\nTel: +91 80 37451377");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"Accolite Software India Private Limited");
	if(a==0){
		printf("\nCompany Description: Accolite Digital is an innovative, best-in-class digital transformation services provider, successfully delivering design-driven complex digital transformation initiatives to Fortune 500 clients. ");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nTel: +91 80 6782 1234");
		printf("\nBranches: Gurugram\nHyderabad");
		printf("\nRating: 3.5");
		printf("\n");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	printf("\n*******************************************************");
   printf("\nDo you want to search about other company:");
   printf("\n");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
	}
}
int manipur(void)
{
  	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000||to<=4500000 && from>=400000){
	printf(" \n The IT Solutions ");
	printf("\n");}
	if(salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000||to<=5000000 && from>=340000){
	printf("\nHadron Techs");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000||to<=3000000 && from>=390000){
	printf("\nTata Consultancy Services Limited");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000||to<=3600000 && from>=300000){
	printf("\nState Bank of India");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=100000&&70<=percentage||to<=4000000 && from>=250000){
	printf("\nProline Infotech");
	printf("\n");}
    if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60||to<=2000000 && from>=200000){
	printf("\nConcentrix");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000||to<=2300000 && from>=150000){
	printf("\nZogam India Technology");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||50<=percentage&&salary<=200000||to<=1500000 && from>=100000){
	printf("\n Excella Infotech");
	printf("\n");}
    manipurc();
	return percentage;
	}	
void manipurc(void)
	{
			int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
    a=strcmpi(company,"The IT Solutions");
    if(a==0)
    {
   	printf("\nThe IT Solutions  :");
   	printf("\nCompany Description: The IT Solutions  is a leading provider of consulting, technology, outsourcing and next-generation digital services, enabling clients around the world to create and execute strategies for their digital transformation. The company also provides digital marketing, artificial intelligence, automation, analytics, engineering services, and Internet of Things services among others. Its subsidiary Infosys BPM provides business process outsourcing services. Infosys makes almost all of its sales overseas, with North America accounting for more than 60% of the total. Key industries served by the company are financial services, insurance, manufacturing, telecom, retail, and consumer goods.");
	printf("\nAddress: Kwakeithel, Imphal West, India");
	printf("\nWebsite: www.infosys.com ");
	printf("\nFax: +91-80-41032140");
	printf("\nEmail: jane.doe@it-solutions.com.mx");
	printf("\nsocial:infosys_limited");
	printf("\nRating: 5.00");
	}
	a=strcmpi(company,"Hadron Techs");
	if(a==0)
	{   
	    printf("\nHadron Techs :");
	    printf("\nCompany Description:Hadron Techs  is a leading global information technology, consulting and business process services company. It provides digital strategy, customer centric design, consulting, infrastructure services, business process services, research and development, cloud, mobility and advanced analytics and product engineering for customers around the world. Operating in some 55 countries, the company generates about 60% of its revenue from the Americas (largely the US). Wipro offers services to companies in a wide range of industries including aerospace and defense, automotive, banking, communications, electronics, construction, healthcare, pharmaceuticals, retail, and oil, and gas. In 2021, Wipro acquired Capco for approximately $1.45 billion.");
		printf("\nAddress: Sapam Biulding, 2nd Floor, imphal - 795001 (Opposite Of Srl Diagnostic),India");
		printf("\nWebsite: www.Hadron Techs .com ");
		printf("\n Email : Hadron@Techs.com ");
		printf("\nFax: +91 80 28440256");
		printf("\nRating: 3.2");	
	}
	a=strcmpi(company,"State Bank of India");
	if(a==0){
		printf("\n State Bank of India");
		printf("\nCompany Description: State Bank of India (SBI) is the nation's largest and oldest bank. Tracing its roots back some 200 years ");
		printf("\nAddress: St Inez Road, Santa Inez, Panaji, Goa, 403001.,india");
		printf("\nWebsite: www.tcs.com ");
		printf("\nTel: 08067242000");
			printf("\n Email : Hadron@Techs.com ");
		printf("\nRating: 4.5");
		}
		a=strcmpi(company,"Proline Infotech");
	if(a==0){
		printf("\n Proline Infotech ");
		printf("\nCompany Description: Registered in 2012 , HCL Technologies Limited has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress:  Sagolband Tera Loukrakpam Leikai, Imphal West,india");
	    printf("\nWebsite: https://www.prolineindia.com");
	    printf("\n Email :Proline@Infotech.com");
		printf("\nPhone Number: (080) 25525792");
		printf("\nRating: 4.0");
	}
		a=strcmpi(company,"Concentrix");
	if(a==0){
		printf("\nCompany Description: In a world full of average, we stand out. We believe experience is everything");
	    printf("\nAddress:5th Delta One Giga Space IT Park Internal Road Viman Nagar Pune Maharashtra 411014 IN, Giga Space IT Park Internal Rd, Sakore Nagar, Viman Nagar, Pune, Maharashtra 411014");
		printf("\nWebsite: www.concentrix.com");
		printf("\n Email :corpsecretary.india@concentrix.com");
		printf("\n Revenue: $2 to $5 billion (USD)");
		printf("\nPhone:+ 91 80 67807777");
		printf("\nRating: 3.7");
	}
		a=strcmpi(company,"Zogam India Technology");
	if(a==0){
		printf("\nZogam India Technology");
		printf("\nCompany Description:Zogam India Technology the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
		printf("\nAddress: Sangaiprou, Imphal West,india");
		printf("\nContact Number: 91 80 67064000");
		printf("\nContact Email:  info@zaubacorp.com");
		printf("\nWebsite:https://www.zogam.com/privacy.html");
		printf("\nRating: 3.7");
	}
			a=strcmpi(company,"Excella Infotech");
	if(a==0){
		printf("\nExcella Infotech");
		printf("\nCompany Description:Zogam India Technology the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
		printf("\nAddress: Sangaiprou, Imphal West,india");
		printf("\nContact Number: 91 80 67064000");
		printf("\nContact Email:  surevinfinvest@gmail.com ");
		printf("\nWebsite: https://www.Excella Infotech.com");
		printf("\nRating: 3.7");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	printf("\n*******************************************************");
   printf("\nDo you want to search about other company:");
   printf("\n");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
	}
}
int gujarat(void)
{
 	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000||to<=6600000 && from>=900000){
	printf(" \nInfosys Limited");
	printf("\n");}
	if(salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000||to<=4300000 && from>=890000){
	printf("\nWipro Limited");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000||to<=5000000 && from>=850000){
	printf("\nTata Consultancy Services Limited");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000||to<=7000000 && from>=800000){
	printf("\nHCL Technologies Limited");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=100000&&70<=percentage||to<=7500000 && from>=500000){
	printf("\nCybage Software Pvt. Ltd.");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60||to<=6500000 && from>=700000){
	printf("\neClinicalWorks India Pvt. Ltd.");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000||to<=7000000 && from>=600000){
	printf("\nGHCL Limited");
	printf("\n");}
	if(80<=percentage&&salary<=2000000||salary<=900000&&65<=percentage||to<=6000000 && from>=400000){
	printf("\nNihilent Limited");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage||to<=5000000 && from>=390000){
	printf("\nCrest Data Systems");
	printf("\n");}
	if(80<=percentage&&salary<=9000000||salary<=800000&&70<=percentage ||to<=4000000 && from>=300000){
	printf("\nSunflower Lab");
	printf("\n");}
	if(85<=percentage&&salary<=5000000|| salary<=500000&&percentage>=60||to<=3000000 && from>=200000){
	printf("\nQuick Heal Technologies Pvt. Ltd.");
	printf("\n");}
	if(80<=percentage&&salary<=1000000|| salary<=400000&&80<=percentage||to<=3600000 && from>=150000){
	printf("\nElitecore Technologies Pvt. Ltd.");
	printf("\n");}
	if(percentage>=85&&salary<=1000000|| salary<=400000&&percentage>60||to<=2500000 && from>=100000){
	printf("\nScript All DNA Technologies");
	printf("\n");}
	if(percentage>=75&&salary<=2000000||salary<=600000&&percentage>=55||to<=1500000 && from>=600000 ){
	printf("\nDeep Technologies");
	printf("\n");}
	if(percentage>=90&&salary<=5000000||salary<=500000&&percentage>=80||to<=1000000 && from>=100000 ){
	printf("\nDRC Systems India Pvt. Ltd.");
	printf("\n");}
	gujaratc();
	return percentage;
	}
	void gujaratc(void)
	{
		int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
    a=strcmpi(company,"Infosys limited");
    if(a==0)
    {
   	printf("\nInfosys Limited");
   	printf("\nCompany Description: Infosys is a leading provider of consulting, technology, outsourcing and next-generation digital services, enabling clients around the world to create and execute strategies for their digital transformation. The company also provides digital marketing, artificial intelligence, automation, analytics, engineering services, and Internet of Things services among others. Its subsidiary Infosys BPM provides business process outsourcing services. Infosys makes almost all of its sales overseas, with North America accounting for more than 60% of the total. Key industries served by the company are financial services, insurance, manufacturing, telecom, retail, and consumer goods.");
	printf("\nAddress:Survey No. 27, IT SEZ, Near Info Tower, Gujarat International Finance Tec-City (GIFT), Gandhinagar - 382355, India");
	printf("\nWebsite: www.infosys.com ");
	printf("\nFax: +91-80-41032140");
	printf("\nEmail: foundation@infosys.com");
	printf("\nsocial:infosys_limited");
	printf("\nRating: 5.00");
	}
	a=strcmpi(company,"Wipro Limited");
	if(a==0)
	{
	    printf("\nCompany Description: Wipro is a leading global information technology, consulting and business process services company. It provides digital strategy, customer centric design, consulting, infrastructure services, business process services, research and development, cloud, mobility and advanced analytics and product engineering for customers around the world. Operating in some 55 countries, the company generates about 60% of its revenue from the Americas (largely the US). Wipro offers services to companies in a wide range of industries including aerospace and defense, automotive, banking, communications, electronics, construction, healthcare, pharmaceuticals, retail, and oil, and gas. In 2021, Wipro acquired Capco for approximately $1.45 billion.");
		printf("\nAddress:  IT/ITES SEZ, InfoCity, Tower 4, 7th floor, Gandhinagar - 382009,india");
		printf("\nRevenue: $10.62 billion\nSales Growth: 27.69%\nNet Income Growth: 13.2%\nAssets: $1.08 million");
		printf("\nWebsite: www.wipro.com ");
		printf("\nFax: +91 80 28440256");
		printf("\n Email : helpdesk.recruitment@wipro.com");
		printf("\nRating: 5.00");	
	}
	a=strcmpi(company,"Tata Consultancy Services Limited");
	if(a==0){
		printf("\nCompany Description: Registered in 2012 , tata consultancy services has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress:  IT/ITES SEZ, SF 2, 2B, 2B/1, 2B/2 and 2B/3 IT/ITES SEZ, Village Shilaj, Taluka Sanand, Ahmedabad - 382210,india");
		printf("\nWebsite: www.tcs.com ");
		printf("\n Email : careers@tcs.com");
		printf("\nTel: 08067242000");
		printf("\nRating: 4.5");
		}
		a=strcmpi(company,"HCL Technologies Limited");
	if(a==0){
		printf("\nCompany Description: Registered in 2012 , HCL Technologies Limited has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress: Block No. 4, SEZ Zone 1, IT/ITES, Special Economic Zone, Survey Number 203/1, Village: Ambavadi, Tal. Sanand, Ahmedabad - 382213,india");
	    printf("\nWebsite: www.hcltech.com");
		printf("\nPhone Number:	080678 10000");
		printf("\n Email : investors@hcl.com ");
		printf("\nRating: 4.0");
	}
		a=strcmpi(company,"Cybage Software Pvt. Ltd.");
	if(a==0){
		printf("\nCompany Description: Cybage Software Pvt. Ltd represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
	    printf("\nAddress:  Unit 203B, 204, 205 & 206, 2nd Floor, Safal Prelude, Nr. Ashwaraj Bunglows, Nr. Prahladnagar Garden, Ahmedabad - 380015,india");
		printf("\nWebsite: https://www.cybage.com");
		printf("\n Email : info@cybage.com");
		printf("\nPhone:+ 91 2066041700");
		printf("\nRating: 3.7");
	}
		a=strcmpi(company,"eClinicalWorks India Pvt. Ltd.");
	if(a==0){
		printf("\nCompany Description:Mindtree Limited  represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
		printf("\nAddress:  Silver Brook Block C, No. 301-306, Near Shukan Platinum, B/H Hotel Pragati The Grand, Anandnagar Road, Prahlad Nagar, Ahmedabad - 380015,india");
		printf("\nContact Number: 91 80 67064000");
		printf("\nContact Email: aum.patel@eclinicalworks.com");
		printf("\nWebsite: https://www.eclinicalworks.com ");
		printf("\nClass of Company: Public");
		printf("\nRating: 3.7");
	}
		a=strcmpi(company,"GHCL Limited");
	if(a==0){
		printf("\nCompany Description: GHCL Limited IT and software development, and business process outsourcing (BPO) services to clients around the world. The company's offerings include application development and maintenance; outsourced IT services (including management of networks, data centers, integration and engineering, security systems, and workplace computer systems).");
		printf("\nAddress: GHCL, IT Tower-1, InfoCity, Gandhinagar - 382009,india ");
		printf("\nRevenue: $1.61 billion\nSales Growth: 23.03%\nNet Income Growth: 17.59%\nAssets: $107,561");
		printf("\nTel: +91 080 4004 4444");
	    printf("\nContact Email: secretarial@ghcl.co.in");
		printf("\nWebsite: wwwhttps://ghcl.co.in ");
		printf("\nRating: 3.5");
		}
		a=strcmpi(company,"Nihilent Limited");
	if(a==0){
		printf("\nCompany Description: LTI (NSE: LTI) is a global technology consulting and digital solutions Company helping more than 420 clients succeed in a converging world.");
		printf("\nAddress: C/209, The First, Behind Keshav Baugh Party Plot, Vastrapur, Ahmedabad - 380052,india");
		printf("\nTel: +91 22 67525656");
		printf("\nFax: +91 22 67525858");
		printf("\nEmail: rahul.bhandari@nihilent.com");
		printf("\nWebsite:https://www.nihilent.com");
		printf("\nRating: 3.5");
	}
		a=strcmpi(company,"Crest Data Systems");
	if(a==0){
		printf("\nCompany Description: Crest Data Systems is a leading Modernization and digital engineering company, headquartered in Bangalore. Sonata provides modernization services using its proprietary Platformation� approach. It specializes in cloud and data modernization, Microsoft Dynamics Modernization, Digital contact center setup and management, managed cloud services and digital transformation services.");
		printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nEmail: jdoe@crestdatasys.com");
       	printf("\nWebsite: https://www.crestdatasys.com");
		printf("\nTel: +91-80-6778 1996");
		printf("\nRating: 3.5");
		}
		a=strcmpi(company,"Sunflower Lab");
	if(a==0){
		printf("\nAddress: 201 Meadows, Behind APMC Market 1, Near GEB office, Mota Varachha, Surat - 394101,india");
		printf("\nWebsite: https://www.thesunflowerlab.com");
		printf("\nTel: +91 080 4544 5445");
		printf("\nEmail: last@thesunflowerlab.com");
		printf("\nRating: 3.5");
	}
		a=strcmpi(company,"Quick Heal Technologies Pvt. Ltd.");
	if(a==0){
		printf("\nCompany Description: We are a technology & innovation company.Delivering business software for Small and Medium Businesses (SMBs) is our passion.What sets a company apart is as much in its DNA as its achievements.");
		printf("\nAddress:  C-11, B.Com Tower, G-2, Near Savvy Swaraaj, Ahmedabad - 380051,india");
		printf("\nTel: +918067582559");
		printf("\nWebsite: https://www.quickheal.co.in");
		printf("\nEmail ID: estore@quickheal.co.in");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"DRC Systems India Pvt. Ltd.");
	if(a==0){
		printf("\nCompany Description: DRC is a leading global technology services and solutions provider, led by Business and Technology Consulting. ITC Infotech provides business-friendly solutions to help clients succeed and be future-ready, by seamlessly bringing together digital expertise, strong industry speci?c alliances and the unique ability to leverage deep domain expertise from ITC Group businesses.");
		printf("\nAddress: 609, Venus Atlantis Corporate Park, Opp. Prahlad Nagar Garden, Anand Nagar Road, Prahlad Nagar, Ahmedabad - 380015,india");
		printf("\nPhone: +91 80 2298 8331-37");
		printf("\nEmail ID: nfo@drcsystems.com");
		printf("\nWebsite: https://www.drcsystems.com");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"Elitecore Technologies Pvt. Ltd.");
	if(a==0){
		printf("\nCompany Description: As a leading strategic partner to companies around the world, we have leveraged technology to enable business transformation for more than 50 years. We address the entire breadth of business needs, from strategy and design to managing operations. To do this, we draw on deep industry expertise and a command of the fast-evolving fields of cloud, data artificial intelligence, connectivity, software, digital engineering, and platforms.");
		printf("\nAddress: 904, Sakar IX, Near Old Reserve Bank of India, Navrangpura, Ahmedabad - 380009,india");
		printf("\nPhone: 080 6656 7000");
		printf("\nEmail ID: cs@elitecore.com");
		printf("\nWebsite:http://www.elitecore.com");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"Script All DNA Technologies");
	if(a==0){
		printf("\nCompany Description: Subex is a pioneer in the space of Digital Trust, providing solutions for 75% of the world�s top 50 telcos. Founded in 1992, the year when the video-telephone was launched, we have been part of the evolution of mobile technology. Today, we are consultants to global telecom carriers for operational excellence and business transformation by driving new revenue models, enhancing the customer experience and optimizing the enterprise.");
		printf("\nAddress:4th Floor, Drive In 22, Nr. Drive In Cinema, Drive In Road, Ahmedabad - 380054,india");
		printf("\nTel: +91 80 37451377");
		printf("\nEmail ID:info@scriptalldna.com");
		printf("\nWebsite:https://scriptalldna.com");
		printf("\nRating: 3.5");
	}
	a=strcmpi(company,"Deep Technologies");
	if(a==0){
		printf("\nCompany Description: Accolite Digital is an innovative, best-in-class digital transformation services provider, successfully delivering design-driven complex digital transformation initiatives to Fortune 500 clients. ");
		printf("\nAddress:  G-24, Below Vodafone Showroom, Sunrise Mall, Nr. Swaminarayan Mandir, Mansi Cross Road, Vastrapur, Ahmedabad - 380015,india");
		printf("\nTel: +91 80 6782 1234");
	    printf("\nEmail ID:  hr@surabhi.io");
		printf("\nWebsite:https://deep.com");
		printf("\nRating: 3.5");
		printf("\n");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	printf("\n*******************************************************");
   printf("\nDo you want to search about other company:");
   printf("\n");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
}
}
int rajasthan(void)
{
	 	int salary,percentage,ch,from,to;
	printf("types of sorting:\n1.According to salary expected and percentage.\n2.Accroding to the package provided(from to to.)\n");
    printf("enter your choise:");
    scanf("%d",&ch);
    if(ch==1){
		printf("\nSorting the company names according to the expected salary and percentage.");
			printf("enter the salary package u want(per year):");
	        scanf("%d",&salary);
		    printf("enter ur percentage:");
	        scanf("%d",&percentage);
	        printf("\nthese are the best companies for you:\n");}
if(ch==2){
		    printf("sorting the company names according to the package bandwidth:");
			printf("\nenter the salary you want from:");
	        scanf("%d",&from);	
	        printf("\nenter the salary you want to:");
	        scanf("%d",&to);
	  }
	printf("\nSEARCHING FOR THE COMPINIES:\n");
	printf("\nThese are the best companies for you:\n");
	if(salary<4300000 && percentage>90||80<=percentage &&salary<=900000||to<=7000000 && from>=900000){
	printf(" \nInfosys Limited");
	printf("\n");}
	if(salary<20000000&&percentage>=85|| 75<=percentage&&salary<=3000000||to<=7500000 && from>=800000){
	printf("\nWipro Limited");
	printf("\n");}
	if(percentage>=80&&salary<=9000000 || percentage>=60&&salary<=1000000||to<=6600000 && from>=700000){
	printf("\nTata Consultancy Services Limited");
	printf("\n");}
	if(percentage>=80&&salary<=7000000 || 65<=percentage&&salary<=2000000||to<=5600000 && from>=600000){
	printf("\nHCL Technologies Limited");
	printf("\n");}
	if(90<=percentage&&salary<=4000000 || salary<=100000&&70<=percentage||to<=4000000 && from>=500000){
	printf("\nTech Mahindra Limited");
	printf("\n");}
	if(85<=percentage&&salary<=3000000 || salary<=500000&&percentage>=60||to<=5000000 && from>=400000){
	printf("\nGenpact");
	printf("\n");}
	if(80<=percentage&&salary<=3000000||60<=percentage&&salary<=300000||to<=4500000 && from>=390000){
	printf("\nCapgemini");
	printf("\n");}
	if(80<=percentage&&salary<=2000000||salary<=900000&&65<=percentage||to<=3600000 && from>=300000){
	printf("\nCognizant Technology Solutions");
	printf("\n");}
	if(90<=percentage&&salary<=5000000|| salary<=400000&&75<=percentage||to<=3000000 && from>=290000){
	printf("\nDXC Technology");
	printf("\n");}
	if(80<=percentage&&salary<=9000000||salary<=800000&&70<=percentage ||to<=1000000 && from>=100000){
	printf("\nEndive Software");
	printf("\n");}
	rajasthanc();
	return percentage;
}
void rajasthanc(void)
{
	int a,z;
	char company[100],yes[3];
	xyz:
	printf("\n****************************************************\n");
	printf("\nenter the company name u want to know about:");
	gets(company);
	gets(company);
    a=strcmpi(company,"Infosys Limited");
    if(a==0)
    {
   	printf("\nInfosys Limited,Tamil nadu :");
   	printf("\nCompany Description: Infosys is a leading provider of consulting, technology, outsourcing and next-generation digital services, enabling clients around the world to create and execute strategies for their digital transformation. The company also provides digital marketing, artificial intelligence, automation, analytics, engineering services, and Internet of Things services among others. Its subsidiary Infosys BPM provides business process outsourcing services. Infosys makes almost all of its sales overseas, with North America accounting for more than 60% of the total. Key industries served by the company are financial services, insurance, manufacturing, telecom, retail, and consumer goods.");
	printf("\nAddress: Plot No. IT-A-001-A-1 Mahindra World City SEZ, Village Kalwara, Tehsil Sanganer, Dist. Jaipur � 302 037, Rajasthan, India");
	printf("\nWebsite: www.infosys.com ");
	printf("\nFax: +91-80-41032140");
	printf("\nEmail: foundation@infosys.com");
	printf("\nsocial:infosys_limited");
	printf("\nRating: 5.00");
	}
	a=strcmpi(company,"Wipro Limited");
	if(a==0)
	{
	    printf("\nCompany Description: Wipro is a leading global information technology, consulting and business process services company. It provides digital strategy, customer centric design, consulting, infrastructure services, business process services, research and development, cloud, mobility and advanced analytics and product engineering for customers around the world. Operating in some 55 countries, the company generates about 60% of its revenue from the Americas (largely the US). Wipro offers services to companies in a wide range of industries including aerospace and defense, automotive, banking, communications, electronics, construction, healthcare, pharmaceuticals, retail, and oil, and gas. In 2021, Wipro acquired Capco for approximately $1.45 billion.");
		printf("\nAddress:  C-92, Ground Floor, Janpath Behind New Vidhan Sabha Lalkothi Scheme, Jaipur Rajasthan-302015,india");
		printf("\nWebsite: www.wipro.com ");
		printf("\nRevenue: $10.62 billion\nSales Growth: 27.69%\nNet Income Growth: 13.2%\nAssets: $1.08 million");
		printf("\nWebsite: www.wipro.com ");
		printf("\nFax: +91 80 28440256");
		printf("\nType: Headquarters\nYear established:	1945");
		printf("\nRating: 5.00");	
	}
	a=strcmpi(company,"Tata Consultancy Services Limited");
	if(a==0){
		printf("\nCompany Description: Registered in 2012 , tata consultancy services has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress: 4.1. Jaipur, Rajasthan,india");
		printf("\nWebsite: www.tcs.com ");
		printf("\nTel: 08067242000");
		printf("\nRating: 4.5");
		}
		a=strcmpi(company,"HCL Technologies Limited");
	if(a==0){
		printf("\nCompany Description: Registered in 2012 , HCL Technologies Limited has gained immense expertise in offering It Services, Technical Consultancy, Custom Application Development etc.We are providing It Services, Technical Consultancy, Custom Application Development to the clients.");
		printf("\nAddress: Behind Vidhan Sabha, Jaipur, , Jaipur, Rajasthan, India - 302001.");
	    printf("\nWebsite: www.hcltech.com");
		printf("\nPhone Number:	080678 10000");
		printf("\nRating: 4.0");
	}
		a=strcmpi(company,"Tech Mahindra Limited");
	if(a==0){
		printf("\nCompany Description: Tech Mahindra represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
	    printf("\nAddress: chennnai,Tamil nadu,india");
		printf("\nWebsite: www.techmahindra.com");
		printf("\nPhone:+ 91 80 67807777");
		printf("\nRating: 3.7");
	}
		a=strcmpi(company,"Genpact");
	if(a==0){
		printf("\nCompany Description:Genpact represents the connected world, offering innovative and customer-centric information technology experiences, enabling Enterprises, Associates and the Society to Rise");
		printf("\nAddress:Jawaharlal Nehru Marg, Malviya Nagar, Near Venkateshwara Temple, Jaipur - 302017, Rajasthan, India");
		printf("\nContact Number:  +91 141 409 2008.");
		printf("\nContact Email:  neha.nakra@genpact.com");
		printf("\nWebsite:http://www.genpact.com");
		printf("\nClass of Company: Public");
		printf("\nRating: 3.7");
	}
		a=strcmpi(company,"Capgemini");
	if(a==0){
		printf("\nCompany Description: Capgemini IT and software development, and business process outsourcing (BPO) services to clients around the world. The company's offerings include application development and maintenance; outsourced IT services (including management of networks, data centers, integration and engineering, security systems, and workplace computer systems).");
		printf("\nAddress: 15 Avenida 5-00. Guatemala City Guatemala 01013,india ");
		printf("\nRevenue: $1.61 billion\nSales Growth: 23.03%\nNet Income Growth: 17.59%\nAssets: $107,561");
		printf("\nTel: +91 080 4004 4444");
		printf("\nContact Email: info@Capgemini.com");
		printf("\nWebsite: www.capgemini.com");
		printf("\nFax: +91 080 4004 9999");
		printf("\nRating: 3.5");
		}
		a=strcmpi(company,"Cognizant Technology Solutions");
	if(a==0){
		printf("\nCompany Description: LTI (NSE: LTI) is a global technology consulting and digital solutions Company helping more than 420 clients succeed in a converging world.");
		printf("\nAddress: Plot No. 192, Shiv Marg, Surya Nagar Gopal Pura By Pass, Jaipur, Rajasthan- 302015,India");
		printf("\nTel: +1 201 801 0233");
		printf("\nFax: (044) 42096000 47426000");
		printf("\nEmail: inquiry@cognizant.com");
		printf("\nWebsite: https://www.cognizant.com/in/en");
		printf("\nRating: 3.5");
	}
		a=strcmpi(company,"DXC Technology");
	if(a==0){
		printf("\nCompany Description: Sonata Software Limited is a leading Modernization and digital engineering company, headquartered in Bangalore. Sonata provides modernization services using its proprietary Platformation� approach. It specializes in cloud and data modernization, Microsoft Dynamics Modernization, Digital contact center setup and management, managed cloud services and digital transformation services.");
		printf("\nAddress: Shop No 35, Kaltara Shopping Area, Shastri Nagar, Jaipur, Rajasthan 302016,india");
		printf("\nEmail:DX@Technology.com");
		printf("\nWebsite: https://dxc.com/in/en");
		printf("\nTel: +91-80-6778 1996");
		printf("\nRating: 3.5");
		}
		a=strcmpi(company,"Endive Software");
	if(a==0){
		printf("\nAddress: 32, Shivaji Marg, Bharti Colony, Rajhans Colony, Indrapuri, Brahampuri, Jaipur, Rajasthan 302002,india");
		printf("\n Email:  accounts@endivesoftware.in ");
		printf("\nWebsite: wwww.endivesoftware.com");
		printf("\nTel: +91 080 4544 5445");
		printf("\nRating: 3.5");
	}
		printf("\n========================================================");
	printf("\nDo you want to send the application for the %s company:",company);
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		
	}
	else{
	printf("\n*******************************************************");
   printf("\nDo you want to search about other company:");
   printf("\n");
	printf("\nenter yes:");
	scanf("%s",yes);
	z=strcmpi(yes,"yes");
	if(z==0){
		goto xyz;
	}
	}	
}



















