
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"header.h"
int state(char* state);
struct job{
	int age;
    char dob[10];
	char mbl[20];
	long ambl;
	int experiance;
	char name[100];
	char fname[100];
    char gender[10];
	char email[100];
	char address[100];
	char civils[10];
	char qualification[30];
	int language;
	int clanguage;
	char lang1[20][30];
	char clang[30][30];
	int graduation;
	char pgraduation[50];
	char qualities[10][20];
	char hobbies[10][20];
	char job[20];
	char eskills[20][20];
	int percentage;	
	float cgpa;		
}p;
int main()
{
 int b=0,i;
char ch;
 printf("\nHello!!welcome to the application");
 printf("\nAre you searching the best jobs suitable for u in a selected place.\nHere is the best way to search for a good job.");
 printf("\nI will assist you to search for a better job.\nenter your details below..\n");
 printf("enter your name:");
 gets(p.name);
 printf("\nenter your age:");
 scanf("%d",&p.age);
if(p.age<=18 || p.age>54){
	printf("sorry!! you are not eligible for the job.");
	exit (0);
}
else{
}
 printf("\nenter your date of birth(dd/mm/year):");
 scanf("%s",p.dob);	
 printf("\nenter your gender:");
 scanf("%s",p.gender);
  printf("\nenter your civil status:");
 scanf("%s",p.civils);
 printf("\nenter your father name:");
 gets(p.fname);
 gets(p.fname);
 printf("\nenter your address(district,village,street,house number):");
 gets(p.address);
     mbl:
    printf("Enter a 10-digit mobile number: ");
    fgets(p.mbl, sizeof(p.mbl), stdin);
    p.mbl[strcspn(p.mbl, "\n")] = '\0';
    if (strlen(p.mbl) == 10) {
        printf("Mobile number is valid.\n");
    } else {
        printf("Entered mobile number is not valid.\n");
        printf("Enter a valid mobile number:");
        goto mbl;
    }
printf("\nenter alternate mobile number:");
 scanf("%Ld",&p.ambl);
 printf("\nenter your Email ID:");
 gets(p.email);
 gets(p.email);
 printf("\nenter your qualification(degree(or)b.tech:");
 scanf("%s",p.qualification);
 
 printf("\nenter year of graduation(0000):");
 scanf("%d",&p.graduation);
  printf("\nenter place of your graduation:");
 gets(p.pgraduation);
  gets(p.pgraduation);
  printf("enter your cgpa:");
  scanf("%f",&p.cgpa);
  if(p.cgpa<=4)
  {
  exit (0);
  }
  
   printf("\nenter how many languages do u know:");
 scanf("%d",&p.language);
 for(i=1;i<=p.language;i++){
 	 printf("enter the language %d:",i); 
 scanf("%s",p.lang1[i]);	
 }
  printf("\nenter how many computer languages do u know:");
 scanf("%d",&p.clanguage);
 for(i=1;i<=p.clanguage;i++){
 	 printf("enter the computer language %d:",i); 
 scanf("%s",p.clang[i]);	
 }
 printf("\nenter your experiance in IT field(if you have any if not enter (0)):");
 scanf("%d",&p.experiance);
  printf("\nenter your hobbies (one by one any 3):");
 for(i=1;i<=3;i++){ 
  gets(p.hobbies[i]);	
 }
  printf("\nenter your qualities (one by one any 3):");
 for(i=1;i<=3;i++){ 
 gets(p.qualities[i]);}
  printf("\nenter your extra skills (one by one any ):");
 for(i=1;i<=3;i++){ 
 gets(p.eskills[i]);
 }
 printf("\nthese are the states available for u:");
b= state(p.job); 
printf("\n======================================================");
printf("\nHere is the application form");
 printf("\n*******************APPLICATION FORM**************");
 printf("\nPERSONAL DETAILS.");
 printf("\nNAME OF THE APPLICANT:%s\nAGE OF THE APPLICANT:%d\nDATE OF THE BIRTH:%s\nGENDER:%s\nCIVIL STATUS:%s",p.name,p.age,p.dob,p.gender,p.civils);
 printf("\nFATHER NAME:%s\nMOBILE NUMBER:%ld\nALTERNATE MOBILE NUMBER:%ld\nEMAIL ADDRESS:%s\nRESIDENTIAL ADDRESS:%s",p.fname,p.mbl,p.ambl,p.email,p.address);
 printf("\n__________________________________________________");
 printf("\nQUALIFICATION DETAILS.");
 printf("\nQUALIFICATION:%s\nCGPA:%.1f\nPLACE OF GRADUATION:%s\nYEAR OF GRADUATION:%d",p.qualification,p.cgpa,p.pgraduation,p.graduation); 
 if(b!=0)
 printf("\nPERCENTAGE:%d",b);
 else{
 }	
  printf("\n__________________________________________________");
  printf("\nEXTRA INFORMATION.");
  printf("\nSKILLS:\n");
  for(i=1;i<=3;i++){ 
 printf("\n%s",p.eskills[i]);
 }
 printf("\nHOBBIES:\n");
  for(i=1;i<=3;i++){ 
printf("\n%s",p.hobbies[i]);	
 }
 printf("\nQUALITIES:\n");
  for(i=1;i<=5;i++){ 
 printf("\n%s",p.qualities[i]);
 }
 printf("\nLANGUAGES KNOWN:\n");
  for(i=1;i<=p.language;i++){
 	 printf("\nLANGUAGE %d:",i); 
     printf("%s",p.lang1[i]);	
 }
 printf("\nCOMPUTER LANGUAGES KNOWN:");
   for(i=1;i<=p.clanguage;i++){
 	 printf("\nCOMPUTER LANGUAGE %d:",i); 
printf("%s",p.clang[i]);	
 }
 printf("\nPREVIOUS JOB EXPERIANCE(years): %d",p.experiance);
 printf("\nCongratulations on this new opportunity!\nThis career move is a perfect fit for you.\nAll the best for your career.\nwait for the reply from the company. the reply will be sent to %s .Thank you have a good day...",p.email);
 
}
